import React, { createContext, useState, useMemo, useCallback, useEffect } from 'react';
import type { User, Wish, Message, Notification, Review, MarketplaceConnection, MarketplaceSettings, ModerationAction, Toy } from '../types';
import { Role, WishStatus, Marketplace } from '../types';
import { MOCK_USERS, MOCK_WISHES, MOCK_NOTIFICATIONS, MOCK_REVIEWS, MOCK_MESSAGES } from '../data/mockData';
import { MOCK_TOYS } from '../data/mockToyData';

// Simple JWT decoder
const decodeJwt = (token: string) => {
  try {
    return JSON.parse(atob(token.split('.')[1]));
  } catch (e) {
    return null;
  }
};

interface DataContextType {
  currentUser: User | null;
  users: User[];
  wishes: Wish[];
  notifications: Notification[];
  reviews: Review[];
  marketplaceConnections: MarketplaceConnection[];
  marketplaceSettings: MarketplaceSettings;
  messages: Message[];
  toys: Toy[];
  login: (email: string, password:string) => boolean;
  loginWithGoogle: (credentialResponse: any) => void;
  logout: () => void;
  signUp: (details: { name: string; email: string; password: string; role: Role; addressLine1?: string; city?: string; postalCode?: string; country?: string; }) => { success: boolean; message?: string };
  getWishById: (id: string) => Wish | undefined;
  getToyById: (id: string) => Toy | undefined;
  getUserById: (id: string) => User | undefined;
  getNotificationsByUserId: (userId: string) => Notification[];
  addWish: (wish: Omit<Wish, 'id' | 'createdAt' | 'dreamerId' | 'likes' | 'reports' | 'moderationHistory' | 'rejectionReason' | 'status'>) => void;
  addToy: (toy: Omit<Toy, 'id' | 'popularity' | 'addedAt'>) => void;
  updateWishStatus: (wishId: string, status: WishStatus, fulfillerId?: string) => void;
  addReview: (review: Omit<Review, 'id'>) => void;
  getReviewsForUser: (userId: string) => Review[];
  getReviewForWishByUser: (wishId: string, reviewerId: string) => Review | undefined;
  deleteUser: (userId: string) => void;
  deleteWish: (wishId: string) => void;
  toggleLikeWish: (wishId: string) => void;
  toggleWishlist: (wishId: string) => void;
  updateUserProfile: (userId: string, updates: { bio: string }) => void;
  getMessagesByWishId: (wishId: string) => Message[];
  sendMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  // Marketplace
  connectMarketplace: (marketplace: Marketplace, apiKey: string) => void;
  disconnectMarketplace: (marketplace: Marketplace) => void;
  updateMarketplaceSettings: (settings: Partial<MarketplaceSettings>) => void;
  // Moderation
  moderateWish: (wishId: string, action: 'Approve' | 'Reject' | 'Hold', reason?: string) => void;
  reportWish: (wishId: string) => void;
}

export const DataContext = createContext<DataContextType>({} as DataContextType);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [wishes, setWishes] = useState<Wish[]>(MOCK_WISHES);
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [toys, setToys] = useState<Toy[]>(MOCK_TOYS);
  const [bannedUserIds, setBannedUserIds] = useState<string[]>([]);
  const [marketplaceConnections, setMarketplaceConnections] = useState<MarketplaceConnection[]>(
    Object.values(Marketplace).map(m => ({ marketplace: m, connected: false }))
  );
  const [marketplaceSettings, setMarketplaceSettings] = useState<MarketplaceSettings>({
    enable2FA: false,
    notifications: { newListings: true, sales: true }
  });

  useEffect(() => {
    setWishes(currentWishes => {
      const THIRTY_DAYS_IN_MS = 30 * 24 * 60 * 60 * 1000;
      const now = new Date();
      let hasChanged = false;

      const updatedWishes = currentWishes.map(wish => {
        if ((wish.status === WishStatus.PENDING || wish.status === WishStatus.IN_PROGRESS) && (now.getTime() - new Date(wish.createdAt).getTime() > THIRTY_DAYS_IN_MS)) {
          hasChanged = true;
          return { ...wish, status: WishStatus.CLOSED };
        }
        return wish;
      });
      
      return hasChanged ? updatedWishes : currentWishes;
    });
  }, []);

  const login = useCallback((email: string, password: string): boolean => {
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (user) {
      if (bannedUserIds.includes(user.id)) {
        return false; // Silently fail login for banned users
      }
      setCurrentUser(user);
      return true;
    }
    return false;
  }, [users, bannedUserIds]);

  const loginWithGoogle = useCallback((credentialResponse: any) => {
    const responsePayload = decodeJwt(credentialResponse.credential);
    if (!responsePayload) {
      console.error("Failed to decode JWT");
      return;
    }

    const { sub: googleId, email, name, picture: avatar } = responsePayload;

    // 1. Check if user exists with this Google ID
    const userByGoogleId = users.find(u => u.googleId === googleId);
    if (userByGoogleId) {
      setCurrentUser(userByGoogleId);
      return;
    }

    // 2. Check if user exists with this email (to link accounts)
    const userByEmail = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (userByEmail) {
      const updatedUser = { ...userByEmail, googleId };
      setUsers(prevUsers => prevUsers.map(u => u.id === userByEmail.id ? updatedUser : u));
      setCurrentUser(updatedUser);
      return;
    }

    // 3. New user: create a new account
    const newUser: User = {
      id: `user-${Date.now()}`,
      googleId,
      name,
      email,
      avatar,
      // Default to Fulfiller as address info is not provided by Google
      role: Role.FULFILLER,
      rating: 0,
      reviews: 0,
      bio: '',
      wishlist: [],
    };
    
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);

  }, [users]);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  const signUp = useCallback((details: { name: string; email: string; password: string; role: Role; addressLine1?: string; city?: string; postalCode?: string; country?: string; }): { success: boolean; message?: string } => {
    const emailExists = users.some(u => u.email.toLowerCase() === details.email.toLowerCase());
    if (emailExists) {
      return { success: false, message: 'An account with this email already exists.' };
    }

    const newUser: User = {
      id: `user-${Date.now()}`,
      name: details.name,
      email: details.email,
      password: details.password,
      role: details.role,
      addressLine1: details.addressLine1,
      city: details.city,
      postalCode: details.postalCode,
      country: details.country,
      avatar: `https://i.pravatar.cc/150?u=user-${Date.now()}`,
      rating: 0,
      reviews: 0,
      bio: '',
      wishlist: [],
    };
    
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);

    return { success: true };
  }, [users]);

  const getWishById = useCallback((id: string) => wishes.find(w => w.id === id), [wishes]);
  const getToyById = useCallback((id: string) => toys.find(t => t.id === id), [toys]);
  const getUserById = useCallback((id: string) => users.find(u => u.id === id), [users]);
  const getNotificationsByUserId = useCallback((userId: string) => notifications.filter(n => n.userId === userId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()), [notifications]);
  const getReviewsForUser = useCallback((userId: string) => reviews.filter(r => r.revieweeId === userId), [reviews]);
  const getReviewForWishByUser = useCallback((wishId: string, reviewerId: string) => reviews.find(r => r.wishId === wishId && r.reviewerId === reviewerId), [reviews]);
  const getMessagesByWishId = useCallback((wishId: string) => messages.filter(m => m.wishId === wishId).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()), [messages]);
  
  const sendMessage = useCallback((message: Omit<Message, 'id' | 'timestamp'>) => {
    const newMessage: Message = {
      ...message,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, newMessage]);
  }, []);

  const createNotification = useCallback((userId: string, message: string) => {
    const newNotification: Notification = {
      id: `notif-${Date.now()}`,
      userId,
      message,
      read: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [newNotification, ...prev]);
  }, []);

  const aiPreCheck = (title: string, description: string): { passes: boolean; reason?: string } => {
    const inappropriateKeywords = ['buy', 'sell', 'crypto', 'nft', 'gun', 'advertisement', 'deals'];
    const unrealisticKeywords = ['moon', 'immortal', 'fly', 'magic', 'time travel', 'private jet', 'own the sun'];
    const combinedText = `${title.toLowerCase()} ${description.toLowerCase()}`;

    if (inappropriateKeywords.some(keyword => combinedText.includes(keyword))) {
      return { passes: false, reason: 'Inappropriate content detected (e.g., advertisement).' };
    }
    if (unrealisticKeywords.some(keyword => combinedText.includes(keyword))) {
      return { passes: false, reason: 'Wish is unrealistic.' };
    }
    return { passes: true };
  };

  const addWish = useCallback((wish: Omit<Wish, 'id' | 'createdAt' | 'dreamerId' | 'likes' | 'reports' | 'moderationHistory' | 'rejectionReason' | 'status'>) => {
    if (!currentUser) return;

    const { passes, reason } = aiPreCheck(wish.title, wish.description);

    const newWish: Wish = {
      ...wish,
      id: `wish-${Date.now()}`,
      dreamerId: currentUser.id,
      createdAt: new Date().toISOString(),
      status: passes ? WishStatus.PENDING_APPROVAL : WishStatus.REJECTED,
      likes: [],
      reports: [],
      moderationHistory: [],
      rejectionReason: passes ? undefined : reason,
    };

    setWishes(prev => [newWish, ...prev]);

    if (!passes) {
      createNotification(currentUser.id, `Your wish "${wish.title}" was automatically rejected. Reason: ${reason}`);
    } else {
      createNotification(currentUser.id, `Your wish "${wish.title}" is pending review.`);
    }
  }, [currentUser, createNotification]);

  const addToy = useCallback((toy: Omit<Toy, 'id' | 'popularity' | 'addedAt'>) => {
    const newToy: Toy = {
      ...toy,
      id: `toy-${Date.now()}`,
      popularity: 0,
      addedAt: new Date().toISOString(),
    };
    setToys(prev => [newToy, ...prev]);
  }, []);

  const updateWishStatus = useCallback((wishId: string, status: WishStatus, fulfillerId?: string) => {
    setWishes(prevWishes =>
      prevWishes.map(w => {
        if (w.id === wishId) {
          const updatedWish = { ...w, status };
          if (fulfillerId) {
            updatedWish.fulfillerId = fulfillerId;
            const fulfiller = getUserById(fulfillerId);
            createNotification(w.dreamerId, `${fulfiller?.name} has offered to fulfill your wish "${w.title}".`);
          }
          if (status === WishStatus.FULFILLED) {
             createNotification(w.dreamerId, `Your wish "${w.title}" has been marked as fulfilled!`);
             if (w.fulfillerId) {
                createNotification(w.fulfillerId, `The wish "${w.title}" has been fulfilled.`);
             }
          }
          return updatedWish;
        }
        return w;
      })
    );
  }, [createNotification, getUserById]);
  
  const addReview = useCallback((review: Omit<Review, 'id'>) => {
    const newReview: Review = { ...review, id: `rev-${Date.now()}` };
    setReviews(prev => [...prev, newReview]);
    setUsers(prevUsers => prevUsers.map(u => {
      if (u.id === review.revieweeId) {
        const oldTotalRating = u.rating * u.reviews;
        const newReviews = u.reviews + 1;
        const newRating = (oldTotalRating + review.rating) / newReviews;
        return { ...u, rating: newRating, reviews: newReviews };
      }
      return u;
    }));
    const reviewer = getUserById(review.reviewerId);
    if(reviewer) {
        createNotification(review.revieweeId, `You have received a ${review.rating}-star rating from ${reviewer.name}.`);
    }
  }, [createNotification, getUserById]);
  
  const deleteUser = useCallback((userId: string) => {
      setUsers(prev => prev.filter(u => u.id !== userId));
  }, []);
  
  const deleteWish = useCallback((wishId: string) => {
      setWishes(prev => prev.filter(w => w.id !== wishId));
  }, []);

  const toggleLikeWish = useCallback((wishId: string) => {
      if(!currentUser) return;
      setWishes(prev => prev.map(w => {
          if(w.id === wishId) {
              const newLikes = w.likes.includes(currentUser.id) 
                  ? w.likes.filter(id => id !== currentUser.id)
                  : [...w.likes, currentUser.id];
              return { ...w, likes: newLikes };
          }
          return w;
      }));
  }, [currentUser]);

  const toggleWishlist = useCallback((wishId: string) => {
    if (!currentUser) return;
    setUsers(prevUsers =>
      prevUsers.map(user => {
        if (user.id === currentUser.id) {
          const newWishlist = user.wishlist.includes(wishId)
            ? user.wishlist.filter(id => id !== wishId)
            : [...user.wishlist, wishId];
          
          // Also update currentUser state directly for immediate UI feedback
          setCurrentUser(prevCurrentUser => prevCurrentUser ? { ...prevCurrentUser, wishlist: newWishlist } : null);
          
          return { ...user, wishlist: newWishlist };
        }
        return user;
      })
    );
  }, [currentUser]);

  const updateUserProfile = useCallback((userId: string, updates: { bio: string }) => {
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
  }, []);

  const connectMarketplace = useCallback((marketplace: Marketplace, apiKey: string) => {
    setMarketplaceConnections(prev => prev.map(c => c.marketplace === marketplace ? { ...c, connected: true, apiKey } : c));
  }, []);

  const disconnectMarketplace = useCallback((marketplace: Marketplace) => {
    setMarketplaceConnections(prev => prev.map(c => c.marketplace === marketplace ? { ...c, connected: false, apiKey: undefined } : c));
  }, []);
  
  const updateMarketplaceSettings = useCallback((settings: Partial<MarketplaceSettings>) => {
    setMarketplaceSettings(prev => ({ ...prev, ...settings }));
  }, []);
  
  const moderateWish = useCallback((wishId: string, action: 'Approve' | 'Reject' | 'Hold', reason?: string) => {
      if(!currentUser || currentUser.role !== Role.ADMIN) return;
      const moderationAction: ModerationAction = {
          adminId: currentUser.id,
          action: action === 'Approve' ? 'Approved' : action === 'Reject' ? 'Rejected' : 'Held',
          timestamp: new Date().toISOString(),
          reason,
      };
      setWishes(prev => prev.map(w => {
          if(w.id === wishId) {
              let newStatus: WishStatus;
              switch(action) {
                  case 'Approve': 
                    newStatus = WishStatus.PENDING;
                    createNotification(w.dreamerId, `Your wish "${w.title}" has been approved!`);
                    break;
                  case 'Reject': 
                    newStatus = WishStatus.REJECTED; 
                    createNotification(w.dreamerId, `Your wish "${w.title}" was rejected. Reason: ${reason}`);
                    break;
                  case 'Hold': 
                    newStatus = WishStatus.UNDER_REVIEW; 
                    break;
                  default:
                    newStatus = w.status;
              }
              return {
                  ...w,
                  status: newStatus,
                  rejectionReason: action === 'Reject' ? reason : w.rejectionReason,
                  moderationHistory: [...w.moderationHistory, moderationAction]
              };
          }
          return w;
      }));
  }, [currentUser, createNotification]);

  const reportWish = useCallback((wishId: string) => {
      if(!currentUser) return;
      setWishes(prev => prev.map(w => {
          if(w.id === wishId && !w.reports.includes(currentUser.id)) {
              return { ...w, reports: [...w.reports, currentUser.id], status: WishStatus.UNDER_REVIEW };
          }
          return w;
      }))
  }, [currentUser]);

  const value = useMemo(() => ({
    currentUser,
    users,
    wishes,
    notifications,
    reviews,
    marketplaceConnections,
    marketplaceSettings,
    messages,
    toys,
    login,
    loginWithGoogle,
    logout,
    signUp,
    getWishById,
    getToyById,
    getUserById,
    getNotificationsByUserId,
    addWish,
    addToy,
    updateWishStatus,
    addReview,
    getReviewsForUser,
    getReviewForWishByUser,
    deleteUser,
    deleteWish,
    toggleLikeWish,
    toggleWishlist,
    updateUserProfile,
    getMessagesByWishId,
    sendMessage,
    connectMarketplace,
    disconnectMarketplace,
    updateMarketplaceSettings,
    moderateWish,
    reportWish,
  }), [
    currentUser, users, wishes, notifications, reviews, marketplaceConnections, marketplaceSettings, messages, toys,
    login, loginWithGoogle, logout, signUp, getWishById, getToyById, getUserById, getNotificationsByUserId, addWish, addToy,
    updateWishStatus, addReview, getReviewsForUser, getReviewForWishByUser, deleteUser,
    deleteWish, toggleLikeWish, toggleWishlist, updateUserProfile, getMessagesByWishId, sendMessage, connectMarketplace, disconnectMarketplace,
    updateMarketplaceSettings, moderateWish, reportWish
  ]);

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};