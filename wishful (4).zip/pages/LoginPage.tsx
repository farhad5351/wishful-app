import React, { useContext, useState, useEffect } from 'react';
import { DataContext } from '../context/DataContext';
import MailIcon from '../components/icons/MailIcon';
import LockIcon from '../components/icons/LockIcon';
import Logo from '../components/Logo';

// This tells TypeScript that the 'google' object will be available on the window
declare const google: any;

interface LoginPageProps {
  setAuthView: (view: 'login' | 'signup') => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ setAuthView }) => {
  const { login, loginWithGoogle } = useContext(DataContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [loginError, setLoginError] = useState('');

  // On component mount, check for a remembered email in localStorage and initialize Google Sign-In
  useEffect(() => {
    const rememberedEmail = localStorage.getItem('rememberedEmail');
    if (rememberedEmail) {
      setEmail(rememberedEmail);
      setRememberMe(true);
    }

    if (typeof google !== 'undefined') {
      google.accounts.id.initialize({
        client_id: process.env.GOOGLE_CLIENT_ID,
        callback: loginWithGoogle
      });

      google.accounts.id.renderButton(
        document.getElementById("google-signin-button"),
        { theme: "outline", size: "large", width: "100%" }
      );
    }
  }, [loginWithGoogle]);

  const validateEmail = (email: string): boolean => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    let isFormValid = true;

    // More robust email validation: checks for presence and format, providing specific errors.
    if (!email.trim()) {
      setEmailError('Email is required.');
      isFormValid = false;
    } else if (!validateEmail(email)) {
      setEmailError('Please enter a valid email address.');
      isFormValid = false;
    } else {
      setEmailError('');
    }

    // Validate password
    if (!password.trim()) {
      setPasswordError('Password is required.');
      isFormValid = false;
    } else {
      setPasswordError('');
    }

    if (!isFormValid) {
      return;
    }

    const loginSuccess = login(email, password);
    if (loginSuccess) {
      // Handle 'Remember me' functionality
      if (rememberMe) {
        localStorage.setItem('rememberedEmail', email);
      } else {
        localStorage.removeItem('rememberedEmail');
      }
    } else {
      setLoginError('Invalid email or password. Please try again.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-100 p-4">
      <div className="w-full max-w-sm mx-auto bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <Logo className="h-16 w-16" />
          </div>
          <h1 className="text-4xl font-bold text-green-600">Wishful</h1>
          <p className="text-slate-500 mt-2">Welcome back! Please sign in.</p>
        </div>
        <form onSubmit={handleLogin} noValidate>
          <div className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <MailIcon className="h-5 w-5 text-slate-400" />
                </span>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setEmailError('');
                    setLoginError('');
                  }}
                  placeholder="you@example.com"
                  className={`w-full pl-10 pr-4 py-2 border rounded-lg bg-slate-50 transition-colors ${emailError ? 'border-red-500' : 'border-slate-300'} focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                  aria-invalid={!!emailError}
                  aria-describedby="email-error"
                />
              </div>
              {emailError && <p id="email-error" className="text-red-500 text-xs mt-1">{emailError}</p>}
            </div>
            <div>
              <label htmlFor="password"  className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <LockIcon className="h-5 w-5 text-slate-400" />
                </span>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setPasswordError('');
                    setLoginError('');
                  }}
                  placeholder="••••••••"
                  className={`w-full pl-10 pr-4 py-2 border rounded-lg bg-slate-50 transition-colors ${passwordError ? 'border-red-500' : 'border-slate-300'} focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                  aria-invalid={!!passwordError}
                  aria-describedby="password-error"
                />
              </div>
              {passwordError && <p id="password-error" className="text-red-500 text-xs mt-1">{passwordError}</p>}
            </div>
          </div>

          <div className="flex items-center justify-between mt-6">
              <div className="flex items-center">
                  <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-slate-700">Remember me</label>
              </div>
              <div className="text-sm">
                  <a href="#" className="font-medium text-green-600 hover:text-green-500">
                      Forgot password?
                  </a>
              </div>
          </div>
          
          {loginError && <p className="text-red-500 text-sm text-center mt-4">{loginError}</p>}

          <div className="mt-6">
            <button
              type="submit"
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-transform hover:scale-105"
            >
              Sign In
            </button>
          </div>
        </form>

        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-slate-500">Or continue with</span>
            </div>
          </div>
          <div id="google-signin-button" className="mt-6 flex justify-center"></div>
        </div>

        <div className="mt-6 text-center">
          <p className="text-sm text-slate-600">
            Don't have an account?{' '}
            <a href="#" onClick={(e) => { e.preventDefault(); setAuthView('signup'); }} className="font-medium text-green-600 hover:text-green-500">
              Sign Up
            </a>
          </p>
        </div>
        <div className="mt-6 pt-4 border-t border-slate-200">
          <p className="text-center text-xs text-slate-500">
            User registration confirmation will be sent from <a href="mailto:info@yssind.com" className="font-medium text-slate-600 hover:underline">info@yssind.com</a>.
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
