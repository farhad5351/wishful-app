
import React, { useContext } from 'react';
import type { View } from '../types';
import { DataContext } from '../context/DataContext';

interface NotificationsPageProps {
    setView: (view: View) => void;
}

const NotificationsPage: React.FC<NotificationsPageProps> = ({ setView }) => {
    const { currentUser, getNotificationsByUserId } = useContext(DataContext);
    
    if (!currentUser) return null;

    const notifications = getNotificationsByUserId(currentUser.id);
    
    const timeSince = (dateString: string): string => {
        const date = new Date(dateString);
        const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
      
        let interval = seconds / 31536000;
        if (interval > 1) return `${Math.floor(interval)}y ago`;
        
        interval = seconds / 2592000;
        if (interval > 1) return `${Math.floor(interval)}mo ago`;
        
        interval = seconds / 86400;
        if (interval > 1) return `${Math.floor(interval)}d ago`;
      
        interval = seconds / 3600;
        if (interval > 1) return `${Math.floor(interval)}h ago`;
      
        interval = seconds / 60;
        if (interval > 1) return `${Math.floor(interval)}m ago`;
      
        return `${Math.floor(seconds)}s ago`;
    };

    return (
        <div>
            <header className="p-4 border-b border-slate-200 bg-white sticky top-0">
                <h1 className="text-2xl font-bold text-slate-900">Notifications</h1>
            </header>
            <div className="p-2">
                {notifications.length > 0 ? (
                    notifications.map(notification => (
                        <div key={notification.id} className={`p-4 mb-2 rounded-lg shadow-sm ${notification.read ? 'bg-white' : 'bg-indigo-50'}`}>
                           <p className="text-slate-800">{notification.message}</p>
                           <p className="text-xs text-slate-500 text-right mt-2">{timeSince(notification.createdAt)}</p>
                        </div>
                    ))
                ) : (
                    <div className="text-center p-10 text-slate-500">
                        <p>You have no notifications.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default NotificationsPage;
