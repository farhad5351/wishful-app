import React, { useState, useContext, useEffect } from 'react';
import type { View, Toy } from '../types';
import { WishCategory } from '../types';
import { DataContext } from '../context/DataContext';

interface CreateWishPageProps {
  setView: (view: View) => void;
  toy?: Toy;
}

const CreateWishPage: React.FC<CreateWishPageProps> = ({ setView, toy }) => {
  const { addWish } = useContext(DataContext);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<WishCategory>(WishCategory.ITEMS);
  const [productUrl, setProductUrl] = useState('');

  useEffect(() => {
    if (toy) {
      setTitle(`A wish for ${toy.name}`);
      setDescription(`I would love to receive a ${toy.name}. \n\nHere's the original description: "${toy.description}"`);
      setCategory(WishCategory.ITEMS);
    }
  }, [toy]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim() && description.trim() && category) {
      addWish({ title, description, category, productUrl });
      setView({ name: 'home' });
    }
  };

  const handleCancel = () => {
    setView({ name: 'home' });
  };

  return (
    <div>
      <header className="p-4 border-b border-slate-200">
        <button onClick={handleCancel} className="text-indigo-600 mb-2">
          ← Back
        </button>
        <h1 className="text-2xl font-bold text-slate-900">Make a Wish</h1>
        <p className="text-sm text-slate-500 mt-1">Your wish will be reviewed by our team before it is published.</p>
      </header>
      <form onSubmit={handleSubmit} className="p-4 space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-slate-700">Wish Title</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="e.g., Help with gardening"
            required
          />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700">Description</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="Describe your wish in a bit more detail."
            required
          />
        </div>
        <div>
          <label htmlFor="productUrl" className="block text-sm font-medium text-slate-700">Product URL (Optional)</label>
          <input
            type="url"
            id="productUrl"
            value={productUrl}
            onChange={(e) => setProductUrl(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="https://example.com/product-page"
          />
        </div>
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-slate-700">Category</label>
          <select
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value as WishCategory)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          >
            {Object.values(WishCategory).map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-4">
            <button type="button" onClick={handleCancel} className="w-full justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200">
                Cancel
            </button>
            <button type="submit" className="w-full justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                Submit for Review
            </button>
        </div>
      </form>
    </div>
  );
};

export default CreateWishPage;