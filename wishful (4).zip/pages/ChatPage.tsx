
import React, { useContext, useState, useEffect, useRef } from 'react';
import type { View, User, Wish } from '../types';
import { DataContext } from '../context/DataContext';

interface ChatPageProps {
    wishId: string;
    participant: User;
    setView: (view: View) => void;
}

const ChatPage: React.FC<ChatPageProps> = ({ wishId, participant, setView }) => {
    const { currentUser, getMessagesByWishId, sendMessage, getWishById } = useContext(DataContext);
    const [newMessage, setNewMessage] = useState('');
    const messages = getMessagesByWishId(wishId);
    const wish = getWishById(wishId);

    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages.length]);

    if (!currentUser || !wish) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim()) {
            sendMessage({ wishId, senderId: currentUser.id, text: newMessage });
            setNewMessage('');
        }
    };

    return (
        <div className="h-full flex flex-col">
            <header className="p-4 border-b border-slate-200 flex items-center space-x-3 bg-white sticky top-0 z-10">
                <button onClick={() => setView({ name: 'messages' })} className="text-indigo-600 font-bold">←</button>
                <img 
                    src={participant.avatar} 
                    alt={participant.name} 
                    className="w-10 h-10 rounded-full cursor-pointer" 
                    onClick={() => setView({ name: 'profile', userId: participant.id })}
                />
                <div>
                    <h1 
                        className="font-bold cursor-pointer hover:underline"
                        onClick={() => setView({ name: 'profile', userId: participant.id })}
                    >
                        {participant.name}
                    </h1>
                    <p className="text-xs text-slate-500 truncate">re: {wish.title}</p>
                </div>
            </header>
            <div className="flex-grow p-4 overflow-y-auto">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex mb-4 ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`rounded-lg p-3 max-w-xs ${msg.senderId === currentUser.id ? 'bg-indigo-500 text-white' : 'bg-slate-200 text-slate-800'}`}>
                            <p>{msg.text}</p>
                            <p className={`text-xs mt-1 ${msg.senderId === currentUser.id ? 'text-indigo-200' : 'text-slate-500'} text-right`}>
                                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSubmit} className="p-4 border-t border-slate-200 bg-white">
                <div className="flex items-center">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="w-full border border-slate-300 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button type="submit" className="ml-3 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-full hover:bg-indigo-700 transition-colors">
                        Send
                    </button>
                </div>
            </form>
        </div>
    );
};

export default ChatPage;