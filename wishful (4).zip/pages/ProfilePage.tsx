import React, { useContext, useState } from 'react';
import { DataContext } from '../context/DataContext';
import type { View } from '../types';
import { Role } from '../types';
import WishCard from '../components/WishCard';
import StarIcon from '../components/icons/StarIcon';
import PencilIcon from '../components/icons/PencilIcon';
import BookmarkIcon from '../components/icons/BookmarkIcon';
import StoreIcon from '../components/icons/StoreIcon';
import LogoutIcon from '../components/icons/LogoutIcon';

interface ProfilePageProps {
  userId: string;
  setView: (view: View) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ userId, setView }) => {
  const { getUserById, getReviewsForUser, wishes, currentUser, logout, updateUserProfile } = useContext(DataContext);
  const user = getUserById(userId);
  const [isEditing, setIsEditing] = useState(false);
  const [editedBio, setEditedBio] = useState('');

  if (!user) {
    return <div>User not found.</div>;
  }
  
  const reviews = getReviewsForUser(user.id);
  const userWishes = wishes.filter(w => w.dreamerId === user.id || w.fulfillerId === user.id);
  const isCurrentUserProfile = currentUser?.id === user.id;

  const handleEditClick = () => {
    setEditedBio(user.bio);
    setIsEditing(true);
  };

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (editedBio.trim()) {
      updateUserProfile(user.id, { bio: editedBio });
      setIsEditing(false);
    } else {
      alert("Bio cannot be empty.");
    }
  };

  return (
    <>
      {isEditing && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-bold mb-4">Edit Profile</h3>
            <form onSubmit={handleProfileUpdate}>
              <label htmlFor="bio" className="block text-sm font-medium text-slate-700">Your Bio</label>
              <textarea
                id="bio"
                value={editedBio}
                onChange={(e) => setEditedBio(e.target.value)}
                rows={4}
                className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Tell us a little about yourself."
                required
              />
              <div className="flex justify-end gap-3 mt-4">
                <button type="button" onClick={() => setIsEditing(false)} className="px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
      <div>
        <header className="p-4 bg-white shadow-sm">
          <div className="flex flex-col items-center">
              <img src={user.avatar} alt={user.name} className="w-24 h-24 rounded-full border-4 border-indigo-200" />
              <h1 className="text-2xl font-bold mt-4">{user.name}</h1>
              <p className="text-slate-500">{user.role}</p>
              <div className="flex items-center mt-2 text-sm text-slate-600">
                  <StarIcon className="w-4 h-4 text-yellow-400 mr-1" />
                  <span>{user.rating.toFixed(1)} ({user.reviews} reviews)</span>
              </div>
          </div>
          <p className="text-center mt-4 text-slate-700">{user.bio}</p>
          {isCurrentUserProfile && user.role === Role.DREAMER && user.addressLine1 && (
            <div className="mt-4 text-center border-t border-slate-200 pt-4 px-4">
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Shipping Address</h3>
                <div className="mt-2 text-slate-700">
                    <p>{user.addressLine1}</p>
                    <p>{user.city}, {user.postalCode}</p>
                    <p>{user.country}</p>
                </div>
            </div>
            )}
          {isCurrentUserProfile && (
             <div className="mt-4 border-t border-slate-200 pt-4">
                <div className="space-y-1">
                    <button onClick={handleEditClick} className="w-full flex items-center gap-4 text-left font-semibold text-slate-700 p-3 rounded-lg hover:bg-slate-100 transition-colors">
                        <PencilIcon className="w-5 h-5 text-slate-500" />
                        <span>Edit Profile</span>
                    </button>
                    {currentUser.role === Role.FULFILLER && (
                        <button onClick={() => setView({ name: 'wishlist' })} className="w-full flex items-center gap-4 text-left font-semibold text-slate-700 p-3 rounded-lg hover:bg-slate-100 transition-colors">
                            <BookmarkIcon className="w-5 h-5 text-slate-500" />
                            <span>My Wishlist</span>
                        </button>
                    )}
                    <button onClick={() => setView({ name: 'marketplaces' })} className="w-full flex items-center gap-4 text-left font-semibold text-slate-700 p-3 rounded-lg hover:bg-slate-100 transition-colors">
                        <StoreIcon className="w-5 h-5 text-slate-500" />
                        <span>Marketplace Connections</span>
                    </button>
                    <button onClick={logout} className="w-full flex items-center gap-4 text-left font-semibold text-red-600 p-3 rounded-lg hover:bg-red-50 transition-colors">
                        <LogoutIcon className="w-5 h-5" />
                        <span>Logout</span>
                    </button>
                </div>
            </div>
          )}
        </header>

        <div className="p-4">
          <h2 className="text-lg font-bold mb-2">Wishes</h2>
          {userWishes.length > 0 ? (
            userWishes.map(wish => <WishCard key={wish.id} wish={wish} setView={setView} />)
          ) : (
            <p className="text-slate-500">No wishes yet.</p>
          )}

          <h2 className="text-lg font-bold mt-6 mb-2">Reviews</h2>
          {reviews.length > 0 ? (
            reviews.map(review => (
              <div key={review.id} className="bg-white p-4 rounded-lg shadow-sm mb-2">
                  <div className="flex items-center">
                      {[...Array(review.rating)].map((_, i) => <span key={`filled-${i}`}><StarIcon className="w-4 h-4 text-yellow-400" /></span>)}
                      {[...Array(5 - review.rating)].map((_, i) => <span key={`empty-${i}`}><StarIcon className="w-4 h-4 text-slate-300" /></span>)}
                  </div>
                <p className="mt-2 text-slate-600">{review.comment}</p>
              </div>
            ))
          ) : (
            <p className="text-slate-500">No reviews yet.</p>
          )}
        </div>
      </div>
    </>
  );
};

export default ProfilePage;