import React, { useContext, useState } from 'react';
import type { View } from '../types';
import { WishStatus, Role } from '../types';
import { DataContext } from '../context/DataContext';
import StarIcon from '../components/icons/StarIcon';
import ShareIcon from '../components/icons/ShareIcon';
import HeartIcon from '../components/icons/HeartIcon';
import FlagIcon from '../components/icons/FlagIcon';

interface WishDetailPageProps {
  wishId: string;
  setView: (view: View) => void;
}

const WishDetailPage: React.FC<WishDetailPageProps> = ({ wishId, setView }) => {
  const { getWishById, getUserById, currentUser, updateWishStatus, addReview, getReviewForWishByUser, toggleLikeWish, reportWish } = useContext(DataContext);
  const wish = getWishById(wishId);
  const [isReviewing, setIsReviewing] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [justReported, setJustReported] = useState(false);

  if (!wish) {
    return <div className="p-4">Wish not found. <button onClick={() => setView({ name: 'home' })} className="text-indigo-600">Go back</button></div>;
  }

  const dreamer = getUserById(wish.dreamerId);
  const fulfiller = wish.fulfillerId ? getUserById(wish.fulfillerId) : null;
  
  const isDreamer = currentUser?.id === wish.dreamerId;
  const isFulfiller = currentUser?.id === wish.fulfillerId;
  const isAdmin = currentUser?.role === Role.ADMIN;
  const existingReview = currentUser ? getReviewForWishByUser(wish.id, currentUser.id) : undefined;
  const reviewTarget = isDreamer ? fulfiller : isFulfiller ? dreamer : null;
  const hasLiked = currentUser ? wish.likes.includes(currentUser.id) : false;
  const hasReported = currentUser ? wish.reports.includes(currentUser.id) : false;

  const canViewWish = wish.status !== WishStatus.PENDING_APPROVAL && wish.status !== WishStatus.UNDER_REVIEW && wish.status !== WishStatus.REJECTED;

  if (!canViewWish && !isDreamer && !isAdmin) {
    return (
        <div className="p-4">
            <button onClick={() => setView({ name: 'home' })} className="text-indigo-600 mb-4">
                ← Back to wishes
            </button>
            <div className="text-center p-10 bg-slate-50 rounded-lg">
                <p className="font-semibold text-slate-700">This wish is currently under review.</p>
                <p className="text-sm text-slate-500 mt-2">Please check back later.</p>
            </div>
        </div>
    );
  }

  const handleFulfill = () => {
    if (currentUser) {
      updateWishStatus(wish.id, WishStatus.IN_PROGRESS, currentUser.id);
    }
  };

  const handleMarkComplete = () => {
    updateWishStatus(wish.id, WishStatus.FULFILLED);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Wishful: ${wish.title}`,
        text: `Check out this wish on Wishful: ${wish.description}`,
        url: window.location.href,
      }).catch(console.error);
    } else {
      alert('Sharing is not supported on your browser.');
    }
  };
  
  const handleLikeClick = () => {
    if (!currentUser) {
      alert('Please log in to like a wish.');
      return;
    }
    toggleLikeWish(wish.id);
  };

  const handleReportClick = () => {
    if (!currentUser) {
      alert('Please log in to report a wish.');
      return;
    }
    if (hasReported) return;
    reportWish(wish.id);
    setJustReported(true);
    setTimeout(() => setJustReported(false), 3000);
  };

  const openReviewModal = () => {
    setRating(0);
    setComment("");
    setIsReviewing(true);
  };
  
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating > 0 && comment.trim() && currentUser && reviewTarget) {
        addReview({
            wishId: wish.id,
            reviewerId: currentUser.id,
            revieweeId: reviewTarget.id,
            rating,
            comment,
        });
        setIsReviewing(false);
    } else {
      alert("Please provide a rating and a comment.");
    }
  };

  const getStatusInfo = () => {
    switch (wish.status) {
      case WishStatus.REJECTED:
        return {
          className: "bg-red-50 text-red-800",
          title: "This wish has been rejected.",
          message: `Reason: ${wish.rejectionReason}`
        };
      case WishStatus.PENDING_APPROVAL:
        return {
          className: "bg-orange-50 text-orange-800",
          title: "This wish is pending approval.",
          message: "It will be visible to others once reviewed by an admin."
        };
       case WishStatus.UNDER_REVIEW:
        return {
          className: "bg-purple-50 text-purple-800",
          title: "This wish is under review.",
          message: "This wish has been reported and is being reviewed by an admin."
        };
      default:
        return null;
    }
  };

  const statusInfo = getStatusInfo();

  return (
    <>
      {isReviewing && reviewTarget && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-bold mb-4">Rate your experience with {reviewTarget.name}</h3>
            <form onSubmit={handleReviewSubmit}>
              <div className="flex justify-center mb-4">
                {[...Array(5)].map((_, i) => {
                  const starValue = i + 1;
                  return (
                    <button type="button" key={starValue} onMouseEnter={() => setHoverRating(starValue)} onMouseLeave={() => setHoverRating(0)} onClick={() => setRating(starValue)} aria-label={`Rate ${starValue} stars`}>
                      <StarIcon className={`w-8 h-8 cursor-pointer transition-colors ${starValue <= (hoverRating || rating) ? 'text-yellow-400' : 'text-slate-300'}`} />
                    </button>
                  );
                })}
              </div>
              <textarea value={comment} onChange={(e) => setComment(e.target.value)} rows={3} className="w-full border border-slate-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Leave a comment..." required />
              <div className="flex justify-end gap-3 mt-4">
                <button type="button" onClick={() => setIsReviewing(false)} className="px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Submit</button>
              </div>
            </form>
          </div>
        </div>
      )}
      <div className="p-4">
        <header className="mb-6">
          <button onClick={() => setView({ name: 'home' })} className="text-indigo-600 mb-4">
            ← Back to wishes
          </button>
          <div className="flex items-center space-x-3">
            <img src={dreamer?.avatar} alt={dreamer?.name} className="w-12 h-12 rounded-full" />
            <div>
              <h1 className="text-xl font-bold">{dreamer?.name}'s Wish</h1>
              <p className="text-sm text-slate-500 cursor-pointer hover:underline" onClick={() => setView({ name: 'profile', userId: dreamer?.id || '' })}>
                View Profile
              </p>
            </div>
          </div>
        </header>

        {statusInfo && (
            <div className={`p-4 rounded-lg mb-4 text-center ${statusInfo.className}`}>
                <p className="font-semibold">{statusInfo.title}</p>
                <p className="text-sm mt-1">{statusInfo.message}</p>
            </div>
        )}

        <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex justify-between items-start">
              <h2 className="text-2xl font-bold text-slate-800">{wish.title}</h2>
              <span className="text-xs font-semibold bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">{wish.category}</span>
            </div>
          <p className="text-slate-600 mt-4">{wish.description}</p>
          <div className="mt-6 pt-4 border-t border-slate-200">
            <p className="text-sm font-semibold">Status: <span className="font-normal">{wish.status}</span></p>
            {fulfiller && <p className="text-sm font-semibold">Fulfiller: <span className="font-normal text-indigo-600 cursor-pointer hover:underline" onClick={() => setView({name: 'profile', userId: fulfiller.id})}>{fulfiller.name}</span></p>}
          </div>
        </div>
        
        <div className="mt-6 space-y-3">
            {wish.status === WishStatus.PENDING && currentUser?.role === Role.FULFILLER && (
                <button onClick={handleFulfill} className="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors">Offer to Fulfill</button>
            )}
             {wish.productUrl && (
              <a href={wish.productUrl} target="_blank" rel="noopener noreferrer" className="block w-full text-center bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                View Product
              </a>
            )}
            {isDreamer && wish.status === WishStatus.IN_PROGRESS && (
                <button onClick={handleMarkComplete} className="w-full bg-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors">Mark as Fulfilled</button>
            )}
            {wish.status === WishStatus.FULFILLED && (
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="font-semibold text-green-800">This wish has been fulfilled! 🎉</p>
                {reviewTarget && !existingReview && (
                   <button onClick={openReviewModal} className="mt-3 bg-yellow-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-yellow-600 transition-colors">Leave a Review</button>
                )}
                {existingReview && (
                    <p className="mt-3 text-sm text-slate-500">You've already left a review.</p>
                )}
              </div>
            )}
             {wish.status === WishStatus.CLOSED && (
              <div className="text-center p-4 bg-slate-100 rounded-lg">
                <p className="font-semibold text-slate-800">This wish has expired and is now closed.</p>
              </div>
            )}
            <div className="flex items-center gap-3">
              <button 
                onClick={handleLikeClick} 
                className={`w-full flex items-center justify-center gap-2 border font-bold py-3 px-4 rounded-lg transition-colors ${hasLiked ? 'border-red-300 bg-red-50 text-red-600 hover:bg-red-100' : 'border-slate-300 text-slate-700 hover:bg-slate-100'}`}
              >
                  <HeartIcon className="w-5 h-5" filled={hasLiked}/> 
                  <span>{hasLiked ? 'Liked' : 'Like'} ({wish.likes.length})</span>
              </button>
              <button 
                onClick={handleShare} 
                className="w-full flex items-center justify-center gap-2 border border-slate-300 text-slate-700 font-bold py-3 px-4 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <ShareIcon className="w-5 h-5"/> Share
              </button>
            </div>
             {canViewWish && currentUser && !isDreamer && (
                <button 
                    onClick={handleReportClick}
                    disabled={hasReported || justReported}
                    className="w-full flex items-center justify-center gap-2 border border-slate-300 text-slate-700 font-bold py-3 px-4 rounded-lg transition-colors enabled:hover:bg-slate-100 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                    <FlagIcon className="w-5 h-5"/> 
                    {justReported ? "Reported!" : hasReported ? "You Reported This" : "Report"}
                </button>
             )}
        </div>
      </div>
    </>
  );
};

export default WishDetailPage;