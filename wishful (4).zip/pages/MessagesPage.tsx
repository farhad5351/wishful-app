

import React, { useContext } from 'react';
import { DataContext } from '../context/DataContext';
import type { View, Message, User } from '../types';

interface MessagesPageProps {
  setView: (view: View) => void;
}

const MessagesPage: React.FC<MessagesPageProps> = ({ setView }) => {
  const { currentUser, messages, wishes, getUserById } = useContext(DataContext);

  if (!currentUser) return null;

  // Filter wishes involving the current user
  const userWishIds = wishes
    .filter(wish => wish.dreamerId === currentUser.id || wish.fulfillerId === currentUser.id)
    .map(wish => wish.id);
  
  // Get last message for each conversation
  const lastMessages = messages
    .filter(msg => userWishIds.includes(msg.wishId))
    // FIX: Using a type assertion on the initial value of `reduce` correctly infers the accumulator's type.
    // This ensures `lastMessages` is properly typed as Record<string, Message> and solves the downstream type errors.
    .reduce((acc, msg) => {
        const existingMsg = acc[msg.wishId];
        if (!existingMsg || new Date(msg.timestamp) > new Date(existingMsg.timestamp)) {
            acc[msg.wishId] = msg;
        }
        return acc;
    }, {} as Record<string, Message>);

  return (
    <div>
      <header className="p-4 border-b border-slate-200 bg-white sticky top-0">
        <h1 className="text-2xl font-bold text-slate-900">Messages</h1>
      </header>
      <div className="p-2">
        {Object.values(lastMessages).length > 0 ? (
          Object.values(lastMessages)
            .sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
            .map(msg => {
            const wish = wishes.find(w => w.id === msg.wishId);
            if (!wish) return null;

            const participantId = wish.dreamerId === currentUser.id ? wish.fulfillerId : wish.dreamerId;
            const participant = getUserById(participantId || '');
            
            if (!participant) return null;

            return (
              <div 
                key={wish.id} 
                className="flex items-center p-4 mb-2 bg-white rounded-lg shadow-sm cursor-pointer hover:bg-slate-50 transition-colors"
                onClick={() => setView({ name: 'chat', wishId: wish.id, participant })}
              >
                <img src={participant.avatar} alt={participant.name} className="w-12 h-12 rounded-full" />
                <div className="ml-4 flex-grow overflow-hidden">
                  <div className="flex justify-between">
                    <p className="font-bold">{participant.name}</p>
                    <p className="text-xs text-slate-400">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                  <p className="text-sm text-slate-600 truncate">
                    {msg.senderId === currentUser.id ? 'You: ' : ''}{msg.text}
                  </p>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center p-10 text-slate-500">
            <p>No messages yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MessagesPage;