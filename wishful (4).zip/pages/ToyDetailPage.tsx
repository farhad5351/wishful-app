import React, { useContext } from 'react';
import type { View } from '../types';
import { Role } from '../types';
import { DataContext } from '../context/DataContext';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';

interface ToyDetailPageProps {
  toyId: string;
  setView: (view: View) => void;
}

const ToyDetailPage: React.FC<ToyDetailPageProps> = ({ toyId, setView }) => {
  const { getToyById, currentUser } = useContext(DataContext);
  const toy = getToyById(toyId);

  if (!toy) {
    return (
      <div className="p-4">
        <h1 className="text-xl font-bold">Toy not found.</h1>
        <button onClick={() => setView({ name: 'toys' })} className="text-indigo-600 mt-4">
          ← Back to Toys
        </button>
      </div>
    );
  }

  const handleMakeWish = () => {
    setView({ name: 'createWish', toy });
  };

  return (
    <div className="h-full flex flex-col">
      <header className="p-4 bg-white sticky top-0 z-10 border-b border-slate-200 flex items-center gap-4">
        <button onClick={() => setView({ name: 'toys' })} className="text-slate-600 hover:text-slate-900">
          <ArrowLeftIcon className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-bold text-slate-900 truncate">{toy.name}</h1>
      </header>
      
      <div className="flex-grow overflow-y-auto">
        <img src={toy.image} alt={toy.name} className="w-full h-64 object-cover" />
        
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-3xl font-bold text-slate-800">{toy.name}</h2>
            <span className="text-3xl font-bold text-green-600">${toy.price.toFixed(2)}</span>
          </div>

          <div className="flex flex-wrap gap-2 mb-6">
            <span className="font-semibold bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">{toy.ageRange}</span>
            <span className="font-semibold bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm">{toy.subCategory}</span>
          </div>

          <h3 className="text-lg font-semibold text-slate-700 mb-2">Description</h3>
          <p className="text-slate-600 leading-relaxed">{toy.description}</p>
        </div>
      </div>
      
      {currentUser?.role === Role.DREAMER && (
        <div className="p-4 bg-white border-t border-slate-200">
          <button 
            onClick={handleMakeWish}
            className="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors shadow-lg"
          >
            Make a Wish for this Toy
          </button>
        </div>
      )}
    </div>
  );
};

export default ToyDetailPage;
