

import React, { useContext, useState, useMemo } from 'react';
import { DataContext } from '../context/DataContext';
import type { View } from '../types';
import { ToyAgeRange, ToySubCategory, Role } from '../types';
import ToyCard from '../components/ToyCard';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';
import SearchIcon from '../components/icons/SearchIcon';
import PlusIcon from '../components/icons/PlusIcon';

interface ToysPageProps {
  setView: (view: View) => void;
  initialAgeRange?: ToyAgeRange;
}

const ToysPage: React.FC<ToysPageProps> = ({ setView, initialAgeRange }) => {
  const { toys, currentUser } = useContext(DataContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [ageFilter, setAgeFilter] = useState<ToyAgeRange | 'All'>(initialAgeRange || 'All');
  const [categoryFilter, setCategoryFilter] = useState<ToySubCategory | 'All'>('All');
  const [priceFilter, setPriceFilter] = useState<number>(100);
  const [sortBy, setSortBy] = useState<'Popularity' | 'PriceLowHigh' | 'PriceHighLow' | 'Newest'>('Popularity');

  const filteredAndSortedToys = useMemo(() => {
    return toys
      .filter(toy => {
        const searchMatch = toy.name.toLowerCase().includes(searchTerm.toLowerCase());
        const ageMatch = ageFilter === 'All' || toy.ageRange === ageFilter;
        const categoryMatch = categoryFilter === 'All' || toy.subCategory === categoryFilter;
        const priceMatch = toy.price <= priceFilter;
        return searchMatch && ageMatch && categoryMatch && priceMatch;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'PriceLowHigh':
            return a.price - b.price;
          case 'PriceHighLow':
            return b.price - a.price;
          case 'Newest':
            return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
          case 'Popularity':
          default:
            return b.popularity - a.popularity;
        }
      });
  }, [toys, searchTerm, ageFilter, categoryFilter, priceFilter, sortBy]);

  return (
    <div className="h-full flex flex-col">
      <header className="p-4 bg-white sticky top-0 z-10 border-b border-slate-200">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => setView({ name: 'home' })} className="text-slate-600 hover:text-slate-900">
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Toys for Kids 3-13 Years</h1>
            <p className="text-sm text-slate-500">Fun and Educational Toys for Children</p>
          </div>
        </div>
        <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <SearchIcon className="h-5 w-5 text-slate-400" />
            </span>
            <input
            type="text"
            placeholder="Search for toys..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-full bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 text-sm">
            <div>
                <label htmlFor="age-filter" className="block font-medium text-slate-700">Age Range</label>
                <select id="age-filter" value={ageFilter} onChange={e => setAgeFilter(e.target.value as any)} className="w-full mt-1 border border-slate-300 rounded-md py-2 px-2 bg-white">
                    <option value="All">All</option>
                    {Object.values(ToyAgeRange).map(age => <option key={age} value={age}>{age}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="category-filter" className="block font-medium text-slate-700">Category</label>
                <select id="category-filter" value={categoryFilter} onChange={e => setCategoryFilter(e.target.value as any)} className="w-full mt-1 border border-slate-300 rounded-md py-2 px-2 bg-white">
                    <option value="All">All</option>
                    {Object.values(ToySubCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="price-filter" className="block font-medium text-slate-700">Max Price: ${priceFilter}</label>
                <input id="price-filter" type="range" min="10" max="100" step="5" value={priceFilter} onChange={e => setPriceFilter(Number(e.target.value))} className="w-full mt-2" />
            </div>
            <div>
                <label htmlFor="sort-by" className="block font-medium text-slate-700">Sort By</label>
                <select id="sort-by" value={sortBy} onChange={e => setSortBy(e.target.value as any)} className="w-full mt-1 border border-slate-300 rounded-md py-2 px-2 bg-white">
                    <option value="Popularity">Popularity</option>
                    <option value="Newest">Newest</option>
                    <option value="PriceLowHigh">Price: Low to High</option>
                    <option value="PriceHighLow">Price: High to Low</option>
                </select>
            </div>
        </div>
      </header>
      <div className="flex-grow overflow-y-auto p-4">
        {filteredAndSortedToys.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {filteredAndSortedToys.map(toy => <ToyCard key={toy.id} toy={toy} setView={setView} />)}
          </div>
        ) : (
          <div className="text-center py-10 text-slate-500">
            <p className="font-semibold">No toys found!</p>
            <p className="text-sm">Try adjusting your filters or search term.</p>
          </div>
        )}
      </div>
      {currentUser?.role === Role.ADMIN && (
        <button
          onClick={() => setView({ name: 'createToy' })}
          className="fixed bottom-20 right-5 bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-transform hover:scale-110 z-20"
          aria-label="Add new toy"
        >
          <PlusIcon className="h-6 w-6" />
        </button>
      )}
    </div>
  );
};

export default ToysPage;