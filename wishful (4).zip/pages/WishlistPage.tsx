import React, { useContext } from 'react';
import { DataContext } from '../context/DataContext';
import type { View } from '../types';
import WishCard from '../components/WishCard';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';

interface WishlistPageProps {
  setView: (view: View) => void;
}

const WishlistPage: React.FC<WishlistPageProps> = ({ setView }) => {
  const { currentUser, wishes } = useContext(DataContext);

  if (!currentUser) {
    // Should not happen if page is protected, but good practice
    return <div className="p-4">Please log in to see your wishlist.</div>;
  }

  const wishlistWishes = wishes.filter(wish => currentUser.wishlist.includes(wish.id));

  return (
    <div className="h-full flex flex-col">
      <header className="p-4 bg-white sticky top-0 z-10 border-b border-slate-200 flex items-center gap-4">
        <button onClick={() => setView({ name: 'profile', userId: currentUser.id })} className="text-slate-600 hover:text-slate-900">
            <ArrowLeftIcon className="h-6 w-6" />
        </button>
        <div>
            <h1 className="text-2xl font-bold text-slate-900">My Wishlist</h1>
            <p className="text-sm text-slate-500">Wishes you've saved to fulfill later.</p>
        </div>
      </header>
      <div className="flex-grow overflow-y-auto p-4">
        {wishlistWishes.length > 0 ? (
          wishlistWishes.map(wish => <WishCard key={wish.id} wish={wish} setView={setView} />)
        ) : (
          <div className="text-center py-20 px-4 text-slate-500">
            <h2 className="text-lg font-semibold">Your wishlist is empty.</h2>
            <p className="mt-2">Save wishes by tapping the bookmark icon.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default WishlistPage;
