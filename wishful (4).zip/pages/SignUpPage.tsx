

import React, { useContext, useState } from 'react';
import { DataContext } from '../context/DataContext';
import { Role } from '../types';
import Logo from '../components/Logo';
import UserIcon from '../components/icons/UserIcon';
import MailIcon from '../components/icons/MailIcon';
import LockIcon from '../components/icons/LockIcon';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';
import { COUNTRIES } from '../data/countryData';

interface SignUpPageProps {
  setAuthView: (view: 'login' | 'signup') => void;
}

const SignUpPage: React.FC<SignUpPageProps> = ({ setAuthView }) => {
  const { signUp } = useContext(DataContext);
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<Role>(Role.DREAMER);
  
  // Address fields
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('US');

  const [nameError, setNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  const [addressError, setAddressError] = useState('');
  const [signUpError, setSignUpError] = useState('');

  const validate = (): boolean => {
    let isValid = true;
    setNameError('');
    setEmailError('');
    setPasswordError('');
    setConfirmPasswordError('');
    setAddressError('');
    setSignUpError('');

    if (!name.trim()) {
      setNameError('Full name is required.');
      isValid = false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address.');
      isValid = false;
    }

    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters long.');
      isValid = false;
    }

    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match.');
      isValid = false;
    }
    
    if (role === Role.DREAMER) {
      if (!addressLine1.trim() || !city.trim() || !postalCode.trim() || !country.trim()) {
        setAddressError('A complete shipping address is required for Dreamers.');
        isValid = false;
      }
    }

    return isValid;
  };
  
  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }
    
    const result = signUp({
      name,
      email,
      password,
      role,
      addressLine1: role === Role.DREAMER ? addressLine1 : undefined,
      city: role === Role.DREAMER ? city : undefined,
      postalCode: role === Role.DREAMER ? postalCode : undefined,
      country: role === Role.DREAMER ? country : undefined,
    });

    if (!result.success) {
      setSignUpError(result.message || 'An unknown error occurred.');
    }
    // On success, App component will switch views automatically
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-100 p-4">
      <div className="w-full max-w-sm mx-auto">
        <div className="mb-4">
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              setAuthView('login');
            }}
            className="flex items-center text-green-600 font-semibold hover:text-green-700 transition-colors"
          >
            <ArrowLeftIcon className="h-5 w-5 mr-2" />
            Back to Sign In
          </a>
        </div>
        <div className="w-full bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Logo className="h-16 w-16" />
            </div>
            <h1 className="text-4xl font-bold text-green-600">Create Account</h1>
            <p className="text-slate-500 mt-2">Join the Wishful community today!</p>
          </div>
          <form onSubmit={handleSignUp} noValidate>
            <div className="space-y-4">
              {/* Name */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <UserIcon className="h-5 w-5 text-slate-400" />
                  </span>
                  <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="John Doe"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg bg-slate-50 transition-colors ${nameError ? 'border-red-500' : 'border-slate-300'} focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent`} required />
                </div>
                {nameError && <p className="text-red-500 text-xs mt-1">{nameError}</p>}
              </div>
              {/* Email */}
              <div>
                <label htmlFor="email-signup" className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <MailIcon className="h-5 w-5 text-slate-400" />
                  </span>
                  <input type="email" id="email-signup" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg bg-slate-50 transition-colors ${emailError ? 'border-red-500' : 'border-slate-300'} focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent`} required />
                </div>
                {emailError && <p className="text-red-500 text-xs mt-1">{emailError}</p>}
              </div>
              {/* Role */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">I want to be a...</label>
                <div className="flex gap-4">
                  <label className="flex items-center p-3 border rounded-lg cursor-pointer flex-1 transition-all hover:border-green-500 has-[:checked]:bg-green-50 has-[:checked]:border-green-600">
                    <input type="radio" name="role" value={Role.DREAMER} checked={role === Role.DREAMER} onChange={() => setRole(Role.DREAMER)} className="h-4 w-4 text-green-600 focus:ring-green-500" />
                    <span className="ml-3 text-sm font-medium text-slate-800">Dreamer</span>
                  </label>
                  <label className="flex items-center p-3 border rounded-lg cursor-pointer flex-1 transition-all hover:border-green-500 has-[:checked]:bg-green-50 has-[:checked]:border-green-600">
                    <input type="radio" name="role" value={Role.FULFILLER} checked={role === Role.FULFILLER} onChange={() => setRole(Role.FULFILLER)} className="h-4 w-4 text-green-600 focus:ring-green-500" />
                    <span className="ml-3 text-sm font-medium text-slate-800">Fulfiller</span>
                  </label>
                </div>
              </div>

              {/* Address Fields */}
              {role === Role.DREAMER && (
                <div className="p-4 border border-green-200 rounded-lg bg-green-50 space-y-4">
                  <p className="text-sm font-medium text-green-800">Dreamers need a shipping address to receive items.</p>
                  <div>
                    <label htmlFor="addressLine1" className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                    <input type="text" id="addressLine1" value={addressLine1} onChange={e => setAddressLine1(e.target.value)} placeholder="123 Main Street" className={`w-full px-4 py-2 border rounded-lg bg-white ${addressError ? 'border-red-500' : 'border-slate-300'}`} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-slate-700 mb-1">City</label>
                      <input type="text" id="city" value={city} onChange={e => setCity(e.target.value)} placeholder="Anytown" className={`w-full px-4 py-2 border rounded-lg bg-white ${addressError ? 'border-red-500' : 'border-slate-300'}`} />
                    </div>
                    <div>
                      <label htmlFor="postalCode" className="block text-sm font-medium text-slate-700 mb-1">Postal Code</label>
                      <input type="text" id="postalCode" value={postalCode} onChange={e => setPostalCode(e.target.value)} placeholder="12345" className={`w-full px-4 py-2 border rounded-lg bg-white ${addressError ? 'border-red-500' : 'border-slate-300'}`} />
                    </div>
                  </div>
                   <div>
                      <label htmlFor="country" className="block text-sm font-medium text-slate-700 mb-1">Country</label>
                      <select id="country" value={country} onChange={e => setCountry(e.target.value)} className={`w-full px-4 py-2 border rounded-lg bg-white ${addressError ? 'border-red-500' : 'border-slate-300'}`}>
                          {COUNTRIES.map(c => <option key={c.iso} value={c.name}>{c.name}</option>)}
                      </select>
                  </div>
                  {addressError && <p className="text-red-500 text-xs mt-1">{addressError}</p>}
                </div>
              )}

              {/* Password */}
              <div>
                <label htmlFor="password-signup" className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <LockIcon className="h-5 w-5 text-slate-400" />
                  </span>
                  <input type="password" id="password-signup" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Minimum 8 characters"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg bg-slate-50 transition-colors ${passwordError ? 'border-red-500' : 'border-slate-300'} focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent`} required />
                </div>
                {passwordError && <p className="text-red-500 text-xs mt-1">{passwordError}</p>}
              </div>
              {/* Confirm Password */}
              <div>
                <label htmlFor="confirm-password" className="block text-sm font-medium text-slate-700 mb-1">Confirm Password</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <LockIcon className="h-5 w-5 text-slate-400" />
                  </span>
                  <input type="password" id="confirm-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="••••••••"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg bg-slate-50 transition-colors ${confirmPasswordError ? 'border-red-500' : 'border-slate-300'} focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent`} required />
                </div>
                {confirmPasswordError && <p className="text-red-500 text-xs mt-1">{confirmPasswordError}</p>}
              </div>
            </div>

            {signUpError && <p className="text-red-500 text-sm text-center mt-4">{signUpError}</p>}

            <div className="mt-6">
              <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-transform hover:scale-105">
                Sign Up
              </button>
            </div>
          </form>
          <div className="mt-6 text-center">
            <p className="text-sm text-slate-600">
              Already have an account?{' '}
              <a href="#" onClick={(e) => { e.preventDefault(); setAuthView('login'); }} className="font-medium text-green-600 hover:text-green-500">
                Sign In
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;