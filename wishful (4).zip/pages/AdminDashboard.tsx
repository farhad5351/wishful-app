import React, { useContext, useState } from 'react';
import { DataContext } from '../context/DataContext';
import { Role, WishStatus, type View, type Wish } from '../types';
import CheckIcon from '../components/icons/CheckIcon';
import XIcon from '../components/icons/XIcon';
import ClockIcon from '../components/icons/ClockIcon';

const AdminDashboard: React.FC<{ setView: (view: View) => void }> = ({ setView }) => {
  const { users, wishes, logout, deleteUser, deleteWish, moderateWish, getUserById } = useContext(DataContext);
  const [activeTab, setActiveTab] = useState<'moderation' | 'users' | 'wishes'>('moderation');
  const [modalState, setModalState] = useState<{ isOpen: boolean; wish: Wish | null; action: 'Reject' | 'Hold' | '' }>({ isOpen: false, wish: null, action: '' });
  const [reason, setReason] = useState('');

  const handleDeleteUser = (userId: string, userName: string) => {
    if (window.confirm(`Are you sure you want to delete user ${userName}? This action cannot be undone.`)) {
      deleteUser(userId);
    }
  };

  const handleDeleteWish = (wishId: string, wishTitle: string) => {
    if (window.confirm(`Are you sure you want to delete the wish "${wishTitle}"? This action cannot be undone.`)) {
      deleteWish(wishId);
    }
  };

  const openModal = (wish: Wish, action: 'Reject' | 'Hold') => {
    setModalState({ isOpen: true, wish, action });
    setReason('');
  };

  const handleModerationSubmit = () => {
    if (modalState.wish && modalState.action) {
      if (modalState.action === 'Reject' && !reason.trim()) {
        alert('A reason is required to reject a wish.');
        return;
      }
      moderateWish(modalState.wish.id, modalState.action, reason);
      setModalState({ isOpen: false, wish: null, action: '' });
    }
  };

  const moderationQueue = wishes.filter(w => w.status === WishStatus.PENDING_APPROVAL || w.status === WishStatus.UNDER_REVIEW).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const TabButton: React.FC<{ tabId: typeof activeTab; title: string, count: number }> = ({ tabId, title, count }) => (
    <button
      onClick={() => setActiveTab(tabId)}
      className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors border-b-2 ${activeTab === tabId ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
    >
      {title} <span className="text-xs bg-slate-200 rounded-full px-2 py-0.5">{count}</span>
    </button>
  );

  return (
    <div className="p-4">
      {modalState.isOpen && modalState.wish && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-bold mb-4">{modalState.action} Wish</h3>
            <p className="text-sm text-slate-600 mb-2">Wish: "{modalState.wish.title}"</p>
            {modalState.action === 'Reject' && (
              <div>
                <label htmlFor="reason" className="block text-sm font-medium text-slate-700">Reason</label>
                <textarea id="reason" value={reason} onChange={(e) => setReason(e.target.value)} rows={3} className="w-full mt-1 border border-slate-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Provide a clear reason for rejection..." required />
              </div>
            )}
            <div className="flex justify-end gap-3 mt-4">
              <button type="button" onClick={() => setModalState({ isOpen: false, wish: null, action: '' })} className="px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200">Cancel</button>
              <button type="button" onClick={handleModerationSubmit} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Confirm</button>
            </div>
          </div>
        </div>
      )}

      <header className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <button onClick={logout} className="bg-red-500 text-white text-sm font-bold py-2 px-4 rounded-lg hover:bg-red-600">
          Logout
        </button>
      </header>

      <div className="border-b border-slate-200 mb-4">
        <nav className="-mb-px flex space-x-4">
          <TabButton tabId="moderation" title="Moderation" count={moderationQueue.length} />
          <TabButton tabId="users" title="Users" count={users.length} />
          <TabButton tabId="wishes" title="All Wishes" count={wishes.length} />
        </nav>
      </div>

      {activeTab === 'moderation' && (
        <section>
          {moderationQueue.length > 0 ? (
            <div className="space-y-3">
              {moderationQueue.map(wish => {
                const dreamer = getUserById(wish.dreamerId);
                return (
                  <div key={wish.id} className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-orange-400">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-bold text-slate-800">{wish.title}</p>
                        <p className="text-xs text-slate-500 mt-1">By: {dreamer?.name} • Status: <span className="font-semibold">{wish.status}</span> {wish.status === WishStatus.UNDER_REVIEW && `(${wish.reports.length} reports)`}</p>
                      </div>
                       <p className="text-xs text-slate-400">{new Date(wish.createdAt).toLocaleDateString()}</p>
                    </div>
                    <p className="text-sm text-slate-600 mt-2 p-2 bg-slate-50 rounded-md">{wish.description}</p>
                    <div className="flex justify-end gap-2 mt-3">
                      <button onClick={() => moderateWish(wish.id, 'Approve')} className="flex items-center gap-1 text-xs font-semibold bg-green-100 text-green-800 px-3 py-1 rounded-full hover:bg-green-200"><CheckIcon className="w-4 h-4" />Approve</button>
                      <button onClick={() => openModal(wish, 'Reject')} className="flex items-center gap-1 text-xs font-semibold bg-red-100 text-red-800 px-3 py-1 rounded-full hover:bg-red-200"><XIcon className="w-4 h-4" />Reject</button>
                      {wish.status !== WishStatus.UNDER_REVIEW && <button onClick={() => moderateWish(wish.id, 'Hold')} className="flex items-center gap-1 text-xs font-semibold bg-purple-100 text-purple-800 px-3 py-1 rounded-full hover:bg-purple-200"><ClockIcon className="w-4 h-4" />Hold</button>}
                    </div>
                  </div>
                )})}
            </div>
          ) : (
            <p className="text-center text-slate-500 py-8">Moderation queue is empty.</p>
          )}
        </section>
      )}

      {activeTab === 'users' && (
        <section className="space-y-2 max-h-96 overflow-y-auto">
          {users.map(user => (
            <div key={user.id} className="bg-white p-3 rounded-lg shadow-sm flex justify-between items-center">
              <div>
                <p className="font-semibold">{user.name}</p>
                <p className="text-sm text-slate-500">{user.email} • {user.role}</p>
              </div>
              <button onClick={() => handleDeleteUser(user.id, user.name)} className="text-xs text-red-500 font-medium hover:underline">
                Delete
              </button>
            </div>
          ))}
        </section>
      )}

      {activeTab === 'wishes' && (
        <section className="space-y-2 max-h-96 overflow-y-auto">
          {wishes.map(wish => (
            <div key={wish.id} className="bg-white p-3 rounded-lg shadow-sm">
              <p className="font-semibold truncate">{wish.title}</p>
              <div className="flex justify-between items-center mt-1">
                <p className="text-sm text-slate-500">Status: {wish.status}</p>
                <button onClick={() => handleDeleteWish(wish.id, wish.title)} className="text-xs text-red-500 font-medium hover:underline">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </section>
      )}
    </div>
  );
};

export default AdminDashboard;
