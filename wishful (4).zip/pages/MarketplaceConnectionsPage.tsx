import React, { useContext } from 'react';
import { DataContext } from '../context/DataContext';
import type { View } from '../types';
import MarketplaceCard from '../components/MarketplaceCard';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';
import ShieldCheckIcon from '../components/icons/ShieldCheckIcon';

const MarketplaceConnectionsPage: React.FC<{ setView: (view: View) => void }> = ({ setView }) => {
  const { marketplaceConnections, marketplaceSettings, updateMarketplaceSettings } = useContext(DataContext);

  const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    if (name === 'enable2FA') {
        updateMarketplaceSettings({ enable2FA: checked });
    } else {
        updateMarketplaceSettings({ notifications: { ...marketplaceSettings.notifications, [name]: checked } });
    }
  };

  return (
    <div className="h-full flex flex-col">
      <header className="p-4 bg-white sticky top-0 z-10 border-b border-slate-200">
        <div className="flex items-center gap-4">
          <button onClick={() => setView({ name: 'profile', userId: '' })} className="text-slate-600 hover:text-slate-900">
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Marketplace Connections</h1>
            <p className="text-sm text-slate-500">Manage your toy marketplace integrations.</p>
          </div>
        </div>
      </header>
      <div className="flex-grow overflow-y-auto p-4 space-y-4">
        <div>
          <h2 className="text-lg font-semibold mb-2 text-slate-800">Connect Accounts</h2>
          <div className="space-y-3">
            {marketplaceConnections.map(conn => (
              <MarketplaceCard key={conn.marketplace} connection={conn} />
            ))}
          </div>
        </div>
        <div>
          <h2 className="text-lg font-semibold mb-2 text-slate-800">Settings</h2>
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheckIcon className="w-6 h-6 text-indigo-600" />
                  <span className="font-medium text-slate-700">Enable 2FA</span>
                </div>
                <label htmlFor="enable2FA" className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" id="enable2FA" name="enable2FA" className="sr-only peer" checked={marketplaceSettings.enable2FA} onChange={handleSettingsChange} />
                  <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
              <div>
                <h3 className="font-medium text-slate-700 mb-2">Notifications</h3>
                <div className="space-y-2">
                    <div className="flex items-center justify-between">
                        <label htmlFor="newListings" className="text-sm text-slate-600">New Listing Approvals</label>
                        <input type="checkbox" id="newListings" name="newListings" checked={marketplaceSettings.notifications.newListings} onChange={handleSettingsChange} className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                    </div>
                     <div className="flex items-center justify-between">
                        <label htmlFor="sales" className="text-sm text-slate-600">Product Sales & Updates</label>
                        <input type="checkbox" id="sales" name="sales" checked={marketplaceSettings.notifications.sales} onChange={handleSettingsChange} className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketplaceConnectionsPage;
