import React, { useState, useContext } from 'react';
import type { View } from '../types';
import { ToyAgeRange, ToySubCategory } from '../types';
import { DataContext } from '../context/DataContext';

interface CreateToyPageProps {
  setView: (view: View) => void;
}

const CreateToyPage: React.FC<CreateToyPageProps> = ({ setView }) => {
  const { addToy } = useContext(DataContext);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [price, setPrice] = useState('');
  const [ageRange, setAgeRange] = useState<ToyAgeRange>(ToyAgeRange.Years3to5);
  const [subCategory, setSubCategory] = useState<ToySubCategory>(ToySubCategory.FUN);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNumber = parseFloat(price);
    if (name.trim() && description.trim() && !isNaN(priceNumber) && priceNumber > 0) {
      addToy({
        name,
        description,
        image: image || `https://placehold.co/600x400/cccccc/ffffff?text=${encodeURIComponent(name)}`,
        price: priceNumber,
        ageRange,
        subCategory,
      });
      setView({ name: 'toys' });
    } else {
        alert("Please fill out all fields correctly. Price must be a valid number.");
    }
  };

  const handleCancel = () => {
    setView({ name: 'toys' });
  };

  return (
    <div>
      <header className="p-4 border-b border-slate-200">
        <button onClick={handleCancel} className="text-indigo-600 mb-2">
          ← Back to Toys
        </button>
        <h1 className="text-2xl font-bold text-slate-900">Add New Toy</h1>
        <p className="text-sm text-slate-500 mt-1">Fill in the details for the new toy listing.</p>
      </header>
      <form onSubmit={handleSubmit} className="p-4 space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700">Toy Name</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="e.g., Colorful Stacking Blocks"
            required
          />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700">Description</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="Describe the toy."
            required
          />
        </div>
        <div>
          <label htmlFor="image" className="block text-sm font-medium text-slate-700">Image URL</label>
          <input
            type="url"
            id="image"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="https://example.com/toy.jpg"
          />
           <p className="text-xs text-slate-500 mt-1">If left blank, a placeholder image will be generated.</p>
        </div>
        <div>
          <label htmlFor="price" className="block text-sm font-medium text-slate-700">Price</label>
          <input
            type="number"
            id="price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="24.99"
            step="0.01"
            min="0"
            required
          />
        </div>
        <div>
          <label htmlFor="ageRange" className="block text-sm font-medium text-slate-700">Age Range</label>
          <select
            id="ageRange"
            value={ageRange}
            onChange={(e) => setAgeRange(e.target.value as ToyAgeRange)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          >
            {Object.values(ToyAgeRange).map((age) => (
              <option key={age} value={age}>{age}</option>
            ))}
          </select>
        </div>
         <div>
          <label htmlFor="subCategory" className="block text-sm font-medium text-slate-700">Category</label>
          <select
            id="subCategory"
            value={subCategory}
            onChange={(e) => setSubCategory(e.target.value as ToySubCategory)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          >
            {Object.values(ToySubCategory).map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-4 pt-4">
            <button type="button" onClick={handleCancel} className="w-full justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200">
                Cancel
            </button>
            <button type="submit" className="w-full justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                Add Toy
            </button>
        </div>
      </form>
    </div>
  );
};

export default CreateToyPage;
