import React, { useContext, useState } from 'react';
import { DataContext } from '../context/DataContext';
import WishCard from '../components/WishCard';
import type { View } from '../types';
import { Role, WishStatus, WishCategory } from '../types';
import PlusIcon from '../components/icons/PlusIcon';
import SearchIcon from '../components/icons/SearchIcon';

interface HomePageProps {
  setView: (view: View) => void;
}

const RetailerRedirectBanner: React.FC = () => (
    <div className="m-4 p-6 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg">
        <h2 className="text-2xl font-bold">Find the perfect item!</h2>
        <p className="mt-2 font-medium">Found something you love on another site? Create a wish and paste the link!</p>
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
            <a href="https://www.amazon.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/20 rounded-lg hover:bg-white/40 transition font-semibold">Amazon</a>
            <a href="https://www.walmart.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/20 rounded-lg hover:bg-white/40 transition font-semibold">Walmart</a>
            <a href="https://www.target.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/20 rounded-lg hover:bg-white/40 transition font-semibold">Target</a>
        </div>
    </div>
);

const HomePage: React.FC<HomePageProps> = ({ setView }) => {
  const { currentUser, wishes } = useContext(DataContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<WishCategory | 'All'>('All');
  const [sortBy, setSortBy] = useState<'Newest' | 'Oldest'>('Newest');

  const roleBasedWishes = wishes.filter(wish => {
    if (currentUser?.role === Role.FULFILLER) {
      return wish.status === WishStatus.PENDING;
    }
    if (currentUser?.role === Role.DREAMER) {
      return wish.dreamerId === currentUser.id;
    }
    // Admin sees all
    return true;
  });
  
  const filteredWishes = roleBasedWishes.filter(wish => {
    const categoryMatch = selectedCategory === 'All' || wish.category === selectedCategory;
    const searchMatch = wish.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        wish.category.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatch && searchMatch;
  }).sort((a, b) => {
    if (sortBy === 'Oldest') {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(); // Default to Newest
  });
  
  const categories: (WishCategory | 'All')[] = ['All', ...Object.values(WishCategory)];

  return (
    <div className="h-full flex flex-col">
      <header className="pt-4 bg-white sticky top-0 z-10 border-b border-slate-200">
        <div className="px-4">
          <div className="flex justify-between items-center mb-4">
              <div>
                  <p className="text-slate-500 text-sm">Welcome back,</p>
                  <h1 className="text-2xl font-bold text-slate-900">{currentUser?.name}!</h1>
              </div>
              <div 
                className="w-10 h-10 rounded-full bg-cover bg-center cursor-pointer"
                style={{ backgroundImage: `url(${currentUser?.avatar})` }}
                onClick={() => setView({ name: 'profile', userId: currentUser?.id || '' })}
                aria-label="View Profile"
              ></div>
          </div>
          <div className="flex items-center gap-2 mb-4">
            <div className="relative flex-grow">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <SearchIcon className="h-5 w-5 text-slate-400" />
              </span>
              <input
                type="text"
                placeholder="Search wishes by title or category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-full bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                aria-label="Search wishes"
              />
            </div>
            <div>
              <label htmlFor="sort-by" className="sr-only">Sort by</label>
              <select
                id="sort-by"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'Newest' | 'Oldest')}
                className="border border-slate-300 rounded-full py-2 pl-3 pr-8 bg-slate-50 text-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Newest">Newest</option>
                <option value="Oldest">Oldest</option>
              </select>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <div className="px-4 pb-3 flex space-x-2">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-colors ${
                  selectedCategory === category
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </header>
      <div className="flex-grow overflow-y-auto pt-0">
        <RetailerRedirectBanner />
        <div className="px-4">
          {filteredWishes.length > 0 ? (
            filteredWishes.map(wish => <WishCard key={wish.id} wish={wish} setView={setView} />)
          ) : (
            <div className="text-center py-10 px-4 text-slate-500">
              {searchTerm || selectedCategory !== 'All' ? (
                  <p>No wishes found.</p>
              ) : (
                  <p>No wishes to show right now.</p>
              )}
            </div>
          )}
        </div>
      </div>

      {currentUser?.role === Role.DREAMER && (
        <button
          onClick={() => setView({ name: 'createWish' })}
          className="fixed bottom-20 right-5 bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-transform hover:scale-110 z-20"
          aria-label="Create new wish"
        >
          <PlusIcon className="h-6 w-6" />
        </button>
      )}
    </div>
  );
};

export default HomePage;