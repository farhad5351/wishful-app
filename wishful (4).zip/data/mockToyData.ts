import type { Toy } from '../types';
import { ToyAgeRange, ToySubCategory } from '../types';

export const MOCK_TOYS: Toy[] = [
  // 3-5 Years
  {
    id: 'toy-1',
    name: 'Soft Plush Elephant',
    description: 'A cuddly and soft plush elephant, perfect for toddlers. Made with child-safe materials.',
    image: 'https://placehold.co/600x400/A8D5E2/FFFFFF?text=Plush+Elephant',
    price: 19.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years3to5,
    subCategory: ToySubCategory.FUN,
    popularity: 85,
    addedAt: '2023-11-01T10:00:00Z',
  },
  {
    id: 'toy-2',
    name: 'Wooden Stacking Blocks',
    description: 'A set of 50 colorful wooden blocks to help develop motor skills and creativity.',
    image: 'https://placehold.co/600x400/F9A825/FFFFFF?text=Stacking+Blocks',
    price: 24.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years3to5,
    subCategory: ToySubCategory.EDUCATIONAL,
    popularity: 95,
    addedAt: '2023-11-02T11:00:00Z',
  },
  {
    id: 'toy-3',
    name: 'Jumbo Animal Puzzle',
    description: 'A 25-piece jumbo floor puzzle featuring friendly safari animals. Great for problem-solving.',
    image: 'https://placehold.co/600x400/81C784/FFFFFF?text=Animal+Puzzle',
    price: 15.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years3to5,
    subCategory: ToySubCategory.EDUCATIONAL,
    popularity: 78,
    addedAt: '2023-10-15T09:00:00Z',
  },

  // 6-9 Years
  {
    id: 'toy-4',
    name: 'Superhero Action Figure',
    description: 'A 12-inch articulated action figure of the famous superhero, Galaxy Guardian.',
    image: 'https://placehold.co/600x400/E53935/FFFFFF?text=Action+Figure',
    price: 14.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years6to9,
    subCategory: ToySubCategory.FUN,
    popularity: 120,
    addedAt: '2023-11-05T14:00:00Z',
  },
  {
    id: 'toy-5',
    name: 'Friendship Bracelet Kit',
    description: 'Everything needed to create beautiful friendship bracelets. Includes colorful threads and beads.',
    image: 'https://placehold.co/600x400/FF80AB/FFFFFF?text=Craft+Kit',
    price: 18.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years6to9,
    subCategory: ToySubCategory.CREATIVE,
    popularity: 110,
    addedAt: '2023-11-03T16:00:00Z',
  },
  {
    id: 'toy-6',
    name: 'Remote Control Car',
    description: 'A fast and durable remote control car that can handle indoor and outdoor terrains.',
    image: 'https://placehold.co/600x400/546E7A/FFFFFF?text=RC+Car',
    price: 34.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years6to9,
    subCategory: ToySubCategory.ELECTRONIC,
    popularity: 150,
    addedAt: '2023-10-28T12:00:00Z',
  },
    {
    id: 'toy-7',
    name: 'Space Explorer Building Set',
    description: 'A 300-piece building set to create a space shuttle, rover, and launchpad.',
    image: 'https://placehold.co/600x400/42A5F5/FFFFFF?text=Space+Set',
    price: 29.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years6to9,
    subCategory: ToySubCategory.BUILDING,
    popularity: 135,
    addedAt: '2023-10-20T10:00:00Z',
  },

  // 10-13 Years
  {
    id: 'toy-8',
    name: 'Beginner Robotics Kit',
    description: 'Build and program your own robot! Includes sensors, motors, and a simple coding interface.',
    image: 'https://placehold.co/600x400/7E57C2/FFFFFF?text=Robotics+Kit',
    price: 59.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years10to13,
    subCategory: ToySubCategory.ELECTRONIC,
    popularity: 90,
    addedAt: '2023-11-04T09:30:00Z',
  },
  {
    id: 'toy-9',
    name: 'Chemistry Volcano Kit',
    description: 'A safe and fun science kit to create your own erupting volcano and learn about chemical reactions.',
    image: 'https://placehold.co/600x400/FF7043/FFFFFF?text=Science+Kit',
    price: 22.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years10to13,
    subCategory: ToySubCategory.EDUCATIONAL,
    popularity: 82,
    addedAt: '2023-10-25T15:00:00Z',
  },
  {
    id: 'toy-10',
    name: 'Advanced Castle Building Set',
    description: 'A challenging 1,200-piece set to construct a detailed medieval castle with figures.',
    image: 'https://placehold.co/600x400/BDBDBD/FFFFFF?text=Castle+Set',
    price: 79.99,
    // FIX: Updated to use enum member
    ageRange: ToyAgeRange.Years10to13,
    subCategory: ToySubCategory.BUILDING,
    popularity: 105,
    addedAt: '2023-10-22T18:00:00Z',
  },
];