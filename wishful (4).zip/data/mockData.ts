import type { User, Wish, Notification, Review, Message } from '../types';
import { Role, WishStatus, WishCategory } from '../types';

export const MOCK_USERS: User[] = [
  { id: 'user-1', name: 'Alice', email: 'alice@example.com', password: 'password123', avatar: 'https://i.pravatar.cc/150?u=user-1', role: Role.DREAMER, rating: 4.8, reviews: 12, bio: 'Loves painting and dreaming of a more colorful world.', addressLine1: '123 Dreamy Lane', city: 'Wishville', postalCode: 'W1S H3S', country: 'United States', wishlist: [] },
  { id: 'user-2', name: 'Bob', email: 'bob@example.com', password: 'password123', avatar: 'https://i.pravatar.cc/150?u=user-2', role: Role.FULFILLER, rating: 4.9, reviews: 25, bio: 'Handyman and problem-solver. Happy to help out where I can.', wishlist: ['wish-3', 'wish-4'] },
  { id: 'user-3', name: 'Charlie', email: 'charlie@example.com', password: 'password123', avatar: 'https://i.pravatar.cc/150?u=user-3', role: Role.DREAMER, rating: 4.5, reviews: 5, bio: 'Aspiring musician looking for a little help to get my start.', addressLine1: '456 Melody Road', city: 'Tune Town', postalCode: 'T1U N3S', country: 'United Kingdom', wishlist: [] },
  { id: 'user-4', name: 'Diana', email: 'diana@example.com', password: 'password123', avatar: 'https://i.pravatar.cc/150?u=user-4', role: Role.FULFILLER, rating: 5.0, reviews: 40, bio: 'Community organizer with a passion for connecting people.', wishlist: [] },
  { id: 'user-admin', name: 'Admin', email: 'admin@example.com', password: 'admin123', avatar: 'https://i.pravatar.cc/150?u=admin', role: Role.ADMIN, rating: 0, reviews: 0, bio: 'Keeping the Wishful community safe and happy.', wishlist: [] },
];

export const MOCK_WISHES: Wish[] = [
  { id: 'wish-1', dreamerId: 'user-1', fulfillerId: 'user-2', title: 'Help painting a mural', description: 'I have a design for a small community mural but need help with the physical painting and supplies.', status: WishStatus.FULFILLED, createdAt: '2023-10-26T10:00:00Z', category: WishCategory.COMMUNITY, likes: ['user-2', 'user-4'], reports: [], moderationHistory: [{ adminId: 'user-admin', action: 'Approved', timestamp: '2023-10-26T09:55:00Z' }] },
  { id: 'wish-2', dreamerId: 'user-3', fulfillerId: 'user-4', title: 'Need a ride for my guitar amp', description: 'I have a gig across town but my amp is too heavy to carry on the bus. Need a ride this Friday evening.', status: WishStatus.IN_PROGRESS, createdAt: '2023-10-25T14:30:00Z', category: WishCategory.TRANSPORT, likes: ['user-1'], reports: [], moderationHistory: [{ adminId: 'user-admin', action: 'Approved', timestamp: '2023-10-25T14:25:00Z' }] },
  { id: 'wish-3', dreamerId: 'user-1', title: 'Someone to teach me basic coding', description: 'I want to build a simple website for my art portfolio. Looking for someone patient to guide me through the basics of HTML/CSS.', status: WishStatus.PENDING, createdAt: '2023-10-24T09:00:00Z', category: WishCategory.EDUCATION, likes: [], reports: ['user-4'], moderationHistory: [{ adminId: 'user-admin', action: 'Approved', timestamp: '2023-10-24T08:55:00Z' }] },
  { id: 'wish-4', dreamerId: 'user-3', title: 'Dog walker for a week', description: 'I broke my leg and need someone to walk my friendly golden retriever, Buddy, for the next week.', status: WishStatus.PENDING, createdAt: '2023-10-27T11:00:00Z', category: WishCategory.HELP, likes: ['user-1', 'user-2', 'user-4'], reports: [], moderationHistory: [{ adminId: 'user-admin', action: 'Approved', timestamp: '2023-10-27T10:55:00Z' }] },
  { id: 'wish-5', dreamerId: 'user-3', title: 'I want a private jet', description: 'Just a small one, like a Gulfstream G650.', status: WishStatus.REJECTED, createdAt: '2023-10-28T10:00:00Z', category: WishCategory.OTHER, likes: [], reports: [], rejectionReason: 'Wish is unrealistic.', moderationHistory: [{ adminId: 'user-admin', action: 'Rejected', timestamp: '2023-10-28T10:05:00Z', reason: 'Wish is unrealistic.' }] },
  { id: 'wish-6', dreamerId: 'user-1', title: 'Learn to play the violin', description: 'Looking for a patient teacher for 2 lessons a week.', status: WishStatus.PENDING_APPROVAL, createdAt: '2023-10-29T11:00:00Z', category: WishCategory.EDUCATION, likes: [], reports: [], moderationHistory: [] },
  { id: 'wish-7', dreamerId: 'user-4', title: 'Buy my awesome products!', description: 'Check out my store for the best deals!', status: WishStatus.REJECTED, createdAt: '2023-10-29T12:00:00Z', category: WishCategory.OTHER, likes: [], reports: [], rejectionReason: 'Inappropriate content detected.', moderationHistory: [] },
  { id: 'wish-8', dreamerId: 'user-1', title: 'Art supplies for my next project', description: 'I need a new set of acrylic paints and some canvases to start my next series of paintings. Any brand would be wonderful!', status: WishStatus.PENDING, createdAt: '2023-11-01T15:00:00Z', category: WishCategory.ITEMS, likes: ['user-4'], reports: [], moderationHistory: [{ adminId: 'user-admin', action: 'Approved', timestamp: '2023-11-01T14:55:00Z' }], productUrl: 'https://www.amazon.com/s?k=acrylic+paint+set' },
];

export const MOCK_NOTIFICATIONS: Notification[] = [
    { id: 'notif-1', userId: 'user-3', message: 'Diana has offered to fulfill your wish "Need a ride for my guitar amp".', read: false, createdAt: '2023-10-25T14:45:00Z' },
    { id: 'notif-2', userId: 'user-1', message: 'Your wish "Help painting a mural" has been marked as fulfilled!', read: true, createdAt: '2023-10-26T18:00:00Z' },
    { id: 'notif-3', userId: 'user-2', message: 'You have received a 5-star rating from Alice.', read: true, createdAt: '2023-10-26T18:05:00Z' },
    { id: 'notif-4', userId: 'user-3', message: 'Your wish "I want a private jet" was automatically rejected. Reason: Wish is unrealistic.', read: false, createdAt: '2023-10-28T10:00:00Z' },
    { id: 'notif-5', userId: 'user-1', message: 'Your wish "Learn to play the violin" is pending review.', read: false, createdAt: '2023-10-29T11:00:00Z' },
];

export const MOCK_REVIEWS: Review[] = [
    { id: 'rev-1', wishId: 'wish-1', reviewerId: 'user-1', revieweeId: 'user-2', rating: 5, comment: 'Bob was incredibly helpful and professional. The mural looks fantastic!' },
    { id: 'rev-2', wishId: 'wish-1', reviewerId: 'user-2', revieweeId: 'user-1', rating: 5, comment: 'Alice was a joy to work with. Her artistic vision is amazing.' },
];

// FIX: Added mock messages for chat functionality
export const MOCK_MESSAGES: Message[] = [
    { id: 'msg-1', wishId: 'wish-2', senderId: 'user-3', text: 'Hey, is the offer for a ride still up?', timestamp: '2023-10-25T14:35:00Z' },
    { id: 'msg-2', wishId: 'wish-2', senderId: 'user-4', text: 'Yes it is! What time works for you?', timestamp: '2023-10-25T14:40:00Z' },
    { id: 'msg-3', wishId: 'wish-1', senderId: 'user-1', text: 'Thanks so much for the help!', timestamp: '2023-10-26T17:50:00Z' },
    { id: 'msg-4', wishId: 'wish-1', senderId: 'user-2', text: 'My pleasure! It was fun.', timestamp: '2023-10-26T17:51:00Z' },
];