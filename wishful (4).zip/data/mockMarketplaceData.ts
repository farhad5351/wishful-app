import { Marketplace } from '../types';

export interface MarketplaceData {
  marketplace: Marketplace;
  inventory: number;
  sales: {
    last7days: number;
    last30days: number;
  };
}

export const MOCK_MARKETPLACE_DATA: MarketplaceData[] = [
  {
    marketplace: Marketplace.AMAZON,
    inventory: 1250,
    sales: { last7days: 150, last30days: 620 },
  },
  {
    marketplace: Marketplace.WALMART,
    inventory: 850,
    sales: { last7days: 95, last30days: 410 },
  },
  {
    marketplace: Marketplace.ENTERTAINER,
    inventory: 420,
    sales: { last7days: 60, last30days: 280 },
  },
  {
    marketplace: Marketplace.SMYTHS,
    inventory: 680,
    sales: { last7days: 110, last30days: 450 },
  },
  {
    marketplace: Marketplace.TOYS_R_US,
    inventory: 300,
    sales: { last7days: 40, last30days: 190 },
  },
  {
    marketplace: Marketplace.HAMLEYS,
    inventory: 215,
    sales: { last7days: 25, last30days: 120 },
  },
];
