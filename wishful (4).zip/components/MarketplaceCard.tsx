import React, { useState, useContext } from 'react';
import type { Marketplace, MarketplaceConnection } from '../types';
import { DataContext } from '../context/DataContext';
import { MOCK_MARKETPLACE_DATA } from '../data/mockMarketplaceData';
import MarketplaceLogo from './icons/MarketplaceLogo';

interface MarketplaceCardProps {
  connection: MarketplaceConnection;
}

const MarketplaceCard: React.FC<MarketplaceCardProps> = ({ connection }) => {
  const { connectMarketplace, disconnectMarketplace } = useContext(DataContext);
  const [apiKey, setApiKey] = useState('');
  const [showModal, setShowModal] = useState(false);

  const data = MOCK_MARKETPLACE_DATA.find(d => d.marketplace === connection.marketplace);

  const handleConnect = () => {
    if (apiKey.trim()) {
      connectMarketplace(connection.marketplace, apiKey);
      setShowModal(false);
    } else {
      alert('Please enter an API Key.');
    }
  };

  return (
    <>
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-bold mb-2">Connect to {connection.marketplace}</h3>
            <p className="text-sm text-slate-500 mb-4">Please enter your API key to connect your account.</p>
            <div>
              <label htmlFor="apiKey" className="block text-sm font-medium text-slate-700">API Key</label>
              <input
                type="text"
                id="apiKey"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="w-full mt-1 border border-slate-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="************"
              />
            </div>
            <div className="flex justify-end gap-3 mt-4">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200">Cancel</button>
              <button onClick={handleConnect} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Connect</button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="p-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <MarketplaceLogo name={connection.marketplace} className="h-8 w-auto" />
            <span className="font-bold text-slate-800">{connection.marketplace}</span>
          </div>
          <button
            onClick={() => connection.connected ? disconnectMarketplace(connection.marketplace) : setShowModal(true)}
            className={`px-3 py-1 text-sm font-semibold rounded-full ${connection.connected ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-green-100 text-green-700 hover:bg-green-200'}`}
          >
            {connection.connected ? 'Disconnect' : 'Connect'}
          </button>
        </div>
        {connection.connected && data && (
          <div className="bg-slate-50 border-t p-4">
            <h4 className="text-sm font-bold text-slate-600 mb-2">Dashboard</h4>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-lg font-bold text-indigo-600">{data.inventory}</p>
                <p className="text-xs text-slate-500">Inventory</p>
              </div>
              <div>
                <p className="text-lg font-bold text-indigo-600">{data.sales.last7days}</p>
                <p className="text-xs text-slate-500">Sales (7d)</p>
              </div>
              <div>
                <p className="text-lg font-bold text-indigo-600">{data.sales.last30days}</p>
                <p className="text-xs text-slate-500">Sales (30d)</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default MarketplaceCard;
