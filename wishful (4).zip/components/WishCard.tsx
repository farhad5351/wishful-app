import React, { useContext } from 'react';
import type { Wish, View } from '../types';
import { WishStatus, Role } from '../types';
import { DataContext } from '../context/DataContext';
import HeartIcon from './icons/HeartIcon';
import BookmarkIcon from './icons/BookmarkIcon';

interface WishCardProps {
  wish: Wish;
  setView: (view: View) => void;
}

const timeSince = (dateString: string): string => {
  const date = new Date(dateString);
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);

  let interval = seconds / 31536000;
  if (interval > 1) return `${Math.floor(interval)}y ago`;
  
  interval = seconds / 2592000;
  if (interval > 1) return `${Math.floor(interval)}mo ago`;
  
  interval = seconds / 86400;
  if (interval > 1) return `${Math.floor(interval)}d ago`;

  interval = seconds / 3600;
  if (interval > 1) return `${Math.floor(interval)}h ago`;

  interval = seconds / 60;
  if (interval > 1) return `${Math.floor(interval)}m ago`;

  return `${Math.floor(seconds)}s ago`;
};

const WishCard: React.FC<WishCardProps> = ({ wish, setView }) => {
  const { getUserById, currentUser, toggleLikeWish, toggleWishlist } = useContext(DataContext);
  const dreamer = getUserById(wish.dreamerId);

  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click from firing
    if (!currentUser) {
      alert('Please log in to like a wish.');
      return;
    }
    toggleLikeWish(wish.id);
  };
  
  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click from firing
    if (!currentUser) {
      alert('Please log in to save wishes.');
      return;
    }
    toggleWishlist(wish.id);
  };

  const hasLiked = currentUser ? wish.likes.includes(currentUser.id) : false;
  const isInWishlist = currentUser?.wishlist?.includes(wish.id) ?? false;
  const canWishlist = currentUser?.role === Role.FULFILLER;

  const getStatusClass = (status: WishStatus) => {
    switch (status) {
      case WishStatus.PENDING_APPROVAL: return "bg-orange-100 text-orange-800";
      case WishStatus.REJECTED: return "bg-red-200 text-red-900";
      case WishStatus.UNDER_REVIEW: return "bg-purple-100 text-purple-800";
      case WishStatus.PENDING: return "bg-yellow-100 text-yellow-800";
      case WishStatus.IN_PROGRESS: return "bg-blue-100 text-blue-800";
      case WishStatus.FULFILLED: return "bg-green-100 text-green-800";
      case WishStatus.CANCELLED: return "bg-red-100 text-red-800";
      case WishStatus.CLOSED: return "bg-slate-100 text-slate-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (!dreamer) return null;

  return (
    <div 
      className="bg-white rounded-xl shadow-md overflow-hidden mb-4 cursor-pointer transition-transform hover:scale-105"
      onClick={() => setView({ name: 'wishDetail', wishId: wish.id })}
    >
      <div className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <img className="h-10 w-10 rounded-full object-cover" src={dreamer.avatar} alt={dreamer.name} />
            <div className="ml-3">
              <p className="text-sm font-semibold text-slate-800">{dreamer.name}</p>
              <p className="text-xs text-slate-500">Dreamer</p>
            </div>
          </div>
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusClass(wish.status)}`}>
            {wish.status}
          </span>
        </div>

        <h3 className="mt-4 text-lg font-bold text-slate-900 truncate">{wish.title}</h3>
        <p className="mt-2 text-slate-600 text-sm line-clamp-2">{wish.description}</p>
        
        <div className="mt-4 pt-4 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500">
          <span className="font-medium bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">{wish.category}</span>
          <div className="flex items-center gap-4">
            {canWishlist && (
                <button 
                onClick={handleWishlistClick} 
                className="flex items-center gap-1 text-slate-500 hover:text-indigo-500 transition-colors"
                aria-label={isInWishlist ? 'Remove from wishlist' : 'Save to wishlist'}
                >
                <BookmarkIcon className={`w-5 h-5 ${isInWishlist ? 'text-indigo-600' : ''}`} filled={isInWishlist} />
                </button>
            )}
            <button 
              onClick={handleLikeClick} 
              className="flex items-center gap-1 text-slate-500 hover:text-red-500 transition-colors"
              aria-label={hasLiked ? 'Unlike wish' : 'Like wish'}
            >
              <HeartIcon className={`w-5 h-5 ${hasLiked ? 'text-red-500' : ''}`} filled={hasLiked} />
              <span className="font-medium">{wish.likes.length}</span>
            </button>
            <span>{timeSince(wish.createdAt)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WishCard;