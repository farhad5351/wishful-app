

import React from 'react';
import type { Toy, View } from '../types';

interface ToyCardProps {
  toy: Toy;
  setView: (view: View) => void;
}

const ToyCard: React.FC<ToyCardProps> = ({ toy, setView }) => {
  return (
    <div 
        className="bg-white rounded-xl shadow-md overflow-hidden mb-4 transition-transform hover:scale-105 flex flex-col cursor-pointer"
        onClick={() => setView({ name: 'toyDetail', toyId: toy.id })}
    >
      <img className="h-48 w-full object-cover" src={toy.image} alt={toy.name} />
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-bold text-slate-900 truncate flex-grow">{toy.name}</h3>
        <div className="mt-2 flex justify-between items-center text-sm">
          <span className="font-semibold bg-blue-100 text-blue-700 px-2 py-1 rounded-full">{toy.ageRange}</span>
          <span className="text-xl font-bold text-green-600">${toy.price.toFixed(2)}</span>
        </div>
        <p className="mt-2 text-slate-600 text-xs line-clamp-2 h-8">{toy.description}</p>
      </div>
    </div>
  );
};

export default ToyCard;