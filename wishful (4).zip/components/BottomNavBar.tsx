

import React, { useContext } from 'react';
import type { View } from '../types';
import HomeIcon from './icons/HomeIcon';
import NotificationIcon from './icons/NotificationIcon';
import ProfileIcon from './icons/ProfileIcon';
import MessageIcon from './icons/MessageIcon';
import StoreIcon from './icons/StoreIcon';
import { DataContext } from '../context/DataContext';

interface BottomNavBarProps {
  view: View;
  setView: (view: View) => void;
}

const BottomNavBar: React.FC<BottomNavBarProps> = ({ view, setView }) => {
  const { currentUser, getNotificationsByUserId } = useContext(DataContext);
  if (!currentUser) return null;

  const unreadCount = getNotificationsByUserId(currentUser.id).filter(n => !n.read).length;

  const navItems = [
    { name: 'home', icon: HomeIcon, label: 'Home' },
    { name: 'toys', icon: StoreIcon, label: 'Toys' },
    { name: 'notifications', icon: NotificationIcon, label: 'Updates', badge: unreadCount },
    { name: 'messages', icon: MessageIcon, label: 'Messages' },
    { name: 'profile', icon: ProfileIcon, label: 'Profile', userId: currentUser.id },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 shadow-t-lg">
      <div className="flex justify-around items-center h-16">
        {navItems.map(item => {
          const isActive = view.name === item.name;
          const colorClass = isActive ? 'text-indigo-600' : 'text-slate-500';
          return (
            <button
              key={item.name}
              onClick={() => setView({ name: item.name as any, userId: item.userId })}
              className={`flex flex-col items-center justify-center w-full text-sm font-medium transition-colors duration-200 ${colorClass} hover:text-indigo-500 relative`}
            >
              <item.icon className="h-6 w-6 mb-1" />
              <span>{item.label}</span>
              {item.badge > 0 && (
                <span className="absolute top-0 right-6 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNavBar;