export enum Role {
  DREAMER = 'Dreamer',
  FULFILLER = 'Fulfiller',
  ADMIN = 'Admin',
}

// New for Marketplace Connections
export enum Marketplace {
  AMAZON = 'Amazon',
  WALMART = 'Walmart',
  ENTERTAINER = 'The Entertainer',
  SMYTHS = 'Smyths',
  TOYS_R_US = 'Toys"R"Us',
  HAMLEYS = 'Hamleys',
}

export interface MarketplaceConnection {
  marketplace: Marketplace;
  connected: boolean;
  apiKey?: string;
}

export interface MarketplaceSettings {
  enable2FA: boolean;
  notifications: {
    newListings: boolean;
    sales: boolean;
  };
}

// FIX: Added missing Toy-related types
export enum ToyAgeRange {
  Years3to5 = '3-5 years',
  Years6to9 = '6-9 years',
  Years10to13 = '10-13 years',
}

export enum ToySubCategory {
  FUN = 'Fun',
  EDUCATIONAL = 'Educational',
  CREATIVE = 'Creative',
  ELECTRONIC = 'Electronic',
  BUILDING = 'Building',
}

export interface Toy {
  id: string;
  name: string;
  description: string;
  image: string;
  price: number;
  ageRange: ToyAgeRange;
  subCategory: ToySubCategory;
  popularity: number;
  addedAt: string;
}


// Updated for Wish Moderation
export enum WishStatus {
  PENDING_APPROVAL = 'Pending Approval',
  REJECTED = 'Rejected',
  UNDER_REVIEW = 'Under Review',
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  FULFILLED = 'Fulfilled',
  CANCELLED = 'Cancelled',
  CLOSED = 'Closed',
}

export enum WishCategory {
  COMMUNITY = 'Community',
  TRANSPORT = 'Transport',
  EDUCATION = 'Education',
  HELP = 'Help',
  TECHNICAL = 'Technical',
  CREATIVE = 'Creative',
  ITEMS = 'Items', 
  OTHER = 'Other',
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; 
  avatar: string;
  role: Role;
  rating: number;
  reviews: number;
  bio: string;
  wishlist: string[];
  googleId?: string;
  // Address fields, required for Dreamers
  addressLine1?: string;
  city?: string;
  postalCode?: string;
  country?: string;
}

// New for Wish Moderation
export interface ModerationAction {
  adminId: string;
  action: 'Approved' | 'Rejected' | 'Held' | 'Restored' | 'Removed';
  timestamp: string;
  reason?: string;
}

// Updated for Wish Moderation
export interface Wish {
  id: string;
  dreamerId: string;
  fulfillerId?: string;
  title: string;
  description: string;
  status: WishStatus;
  createdAt: string;
  category: WishCategory;
  likes: string[];
  reports: string[];
  rejectionReason?: string;
  moderationHistory: ModerationAction[];
  productUrl?: string;
}

export interface Message {
  id: string;
  wishId: string;
  senderId: string;
  text: string;
  timestamp: string;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface Review {
  id: string;
  wishId: string;
  reviewerId: string;
  revieweeId: string;
  rating: number;
  comment: string;
}

export type View =
  | { name: 'home' }
  | { name: 'wishDetail'; wishId: string }
  | { name: 'profile'; userId: string }
  | { name: 'createWish', toy?: Toy }
  | { name: 'createToy' }
  | { name: 'notifications' }
  | { name: 'admin' }
  | { name: 'wishlist' }
  | { name: 'marketplaces' } // New for Marketplace Connections
  | { name: 'messages' }
  | { name: 'toys'; initialAgeRange?: ToyAgeRange }
  | { name: 'toyDetail'; toyId: string }
  | { name: 'chat'; wishId: string; participant: User };