

import React, { useState, useContext } from 'react';
import { DataContext } from './context/DataContext';
import type { View } from './types';
import { Role } from './types';

import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import WishDetailPage from './pages/WishDetailPage';
import ProfilePage from './pages/ProfilePage';
import CreateWishPage from './pages/CreateWishPage';
import NotificationsPage from './pages/NotificationsPage';
import AdminDashboard from './pages/AdminDashboard';
import BottomNavBar from './components/BottomNavBar';
import MarketplaceConnectionsPage from './pages/MarketplaceConnectionsPage';
import SignUpPage from './pages/SignUpPage';
import WishlistPage from './pages/WishlistPage';
import CreateToyPage from './pages/CreateToyPage';
import ToyDetailPage from './pages/ToyDetailPage';
import ToysPage from './pages/ToysPage';
import MessagesPage from './pages/MessagesPage';
import ChatPage from './pages/ChatPage';

const App: React.FC = () => {
  const { currentUser } = useContext(DataContext);
  const [view, setView] = useState<View>({ name: 'home' });
  const [authView, setAuthView] = useState<'login' | 'signup'>('login');

  if (!currentUser) {
    if (authView === 'signup') {
      return <SignUpPage setAuthView={setAuthView} />;
    }
    return <LoginPage setAuthView={setAuthView} />;
  }

  if (currentUser.role === Role.ADMIN) {
    return <AdminDashboard setView={setView} />;
  }

  const renderView = () => {
    switch (view.name) {
      case 'home':
        return <HomePage setView={setView} />;
      case 'toys':
        return <ToysPage setView={setView} initialAgeRange={view.initialAgeRange} />;
      case 'wishDetail':
        return <WishDetailPage wishId={view.wishId} setView={setView} />;
      case 'profile':
        return <ProfilePage userId={view.userId} setView={setView} />;
      case 'createWish':
        return <CreateWishPage setView={setView} toy={view.toy} />;
      case 'createToy':
        return <CreateToyPage setView={setView} />;
      case 'toyDetail':
        return <ToyDetailPage toyId={view.toyId} setView={setView} />;
      case 'notifications':
        return <NotificationsPage setView={setView} />;
      case 'messages':
        return <MessagesPage setView={setView} />;
      case 'chat':
        return <ChatPage wishId={view.wishId} participant={view.participant} setView={setView} />;
      case 'marketplaces':
        return <MarketplaceConnectionsPage setView={setView} />;
      case 'wishlist':
        return <WishlistPage setView={setView} />;
      default:
        return <HomePage setView={setView} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen flex flex-col">
        <main className="flex-grow pb-20">
          {renderView()}
        </main>
        <BottomNavBar view={view} setView={setView} />
      </div>
    </div>
  );
};

export default App;